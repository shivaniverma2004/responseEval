// Core/Network/GeminiAPI.swift
import Foundation

/// Simple wrapper for the free Gemini API.
/// All requests are cached locally to support offline‑first behaviour.
final class GeminiAPI {
    static let shared = GeminiAPI()
    private let baseURL = URL(string: "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent")!
    private let apiKey: String = "<YOUR_GEMINI_API_KEY>" // <-- replace at build time
    private let cache = NSCache<NSURL, NSData>()
    
    private init() {}
    
    enum GeminiFeature: String {
        case summarize = "Summarize"
        case simplify = "Simplify"
        case quiz = "GenerateQuiz"
        case grammar = "ExplainGrammar"
    }
    
    struct GeminiResponse: Decodable {
        struct Candidate: Decodable { let content: Content }
        struct Content: Decodable { let parts: [Part] }
        struct Part: Decodable { let text: String }
        let candidates: [Candidate]
    }
    
    func request(feature: GeminiFeature, inputText: String) async throws -> String {
        // Build prompt based on feature
        let systemPrompt: String
        switch feature {
        case .summarize:
            systemPrompt = "Summarize the following text in 2-3 sentences."
        case .simplify:
            systemPrompt = "Rewrite the following text using simple English, suitable for a learner."
        case .quiz:
            systemPrompt = "Create a short quiz (5 questions) based on the following text."
        case .grammar:
            systemPrompt = "Explain the grammar constructions used in the following passage."
        }
        let fullPrompt = "\(systemPrompt)\n\n\(inputText)"
        var request = URLRequest(url: baseURL)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        let body: [String: Any] = [
            "contents": [["parts": [["text": fullPrompt]]]]
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: body, options: [])
        
        // Check cache first
        if let cached = cache.object(forKey: request.url! as NSURL) {
            let decoded = try JSONDecoder().decode(GeminiResponse.self, from: cached as Data)
            return decoded.candidates.first?.content.parts.first?.text ?? ""
        }
        
        let (data, _) = try await URLSession.shared.data(for: request)
        // Cache response
        cache.setObject(data as NSData, forKey: request.url! as NSURL)
        let response = try JSONDecoder().decode(GeminiResponse.self, from: data)
        return response.candidates.first?.content.parts.first?.text ?? ""
    }
}
