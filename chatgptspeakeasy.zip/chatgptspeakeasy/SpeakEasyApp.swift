import SwiftUI

@main
struct SpeakEasyApp: App {
    // Core Data persistence controller
    let persistenceController = PersistenceController.shared

    // Observe authentication state
    @StateObject private var authViewModel = AuthViewModel()

    var body: some Scene {
        WindowGroup {
            // Root view decides based on auth state
            if authViewModel.isAuthenticated {
                MainTabView()
                    .environmentObject(authViewModel)
                    .environment(
                        \.
                        managedObjectContext, persistenceController.container.viewContext)
            } else {
                LoginView()
                    .environmentObject(authViewModel)
            }
        }
    }
}

// Main tab view containing four tabs
struct MainTabView: View {
    var body: some View {
        TabView {
            DashboardView()
                .tabItem {
                    Label("Dashboard", systemImage: "house.fill")
                }
            ProjectsListView()
                .tabItem {
                    Label("Projects", systemImage: "folder.fill")
                }
            WordBasketView()
                .tabItem {
                    Label("Words", systemImage: "book.fill")
                }
            ProfileView()
                .tabItem {
                    Label("Profile", systemImage: "person.crop.circle")
                }
        }
    }
}
