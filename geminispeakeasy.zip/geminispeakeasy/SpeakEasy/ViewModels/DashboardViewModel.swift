import Foundation
import Combine
import CoreData

@MainActor
final class DashboardViewModel: ObservableObject {
    @Published var userName = "Guest"
    @Published var projectCount = 0
    @Published var wordCount = 0
    @Published var readingGoal = 15 // in minutes
    @Published var currentStreak = 0
    
    @Published var recentProjects: [CDProject] = []
    @Published var recentWords: [CDWord] = []
    @Published var recentActivities: [CDActivity] = []
    
    private let coreData = CoreDataManager.shared
    
    var timeOfDayGreeting: String {
        let hour = Calendar.current.component(.hour, from: Date())
        switch hour {
        case 0..<12: return "Good Morning"
        case 12..<17: return "Good Afternoon"
        default: return "Good Evening"
        }
    }
    
    init() {
        loadSettings()
        fetchDashboardData()
    }
    
    func loadSettings() {
        let defaults = UserDefaults.standard
        self.userName = defaults.string(forKey: Constants.UserDefaultsKeys.userName) ?? "Learner"
        
        let savedGoal = defaults.integer(forKey: Constants.UserDefaultsKeys.dailyReadingGoalMinutes)
        self.readingGoal = savedGoal > 0 ? savedGoal : 15
        
        self.currentStreak = defaults.integer(forKey: Constants.UserDefaultsKeys.currentStreak)
        updateStreakIfNeeded()
    }
    
    func fetchDashboardData() {
        // 1. Project Count & List
        let allProjects = coreData.fetchProjects()
        self.projectCount = allProjects.count
        self.recentProjects = Array(allProjects.prefix(5))
        
        // 2. Word Count & List
        let allWords = coreData.fetchWords()
        self.wordCount = allWords.count
        self.recentWords = Array(allWords.prefix(5))
        
        // 3. Recent Activities
        self.recentActivities = coreData.fetchActivities(limit: 5)
    }
    
    func updateStreakIfNeeded() {
        let defaults = UserDefaults.standard
        let calendar = Calendar.current
        
        guard let lastActiveDate = defaults.object(forKey: Constants.UserDefaultsKeys.lastActiveDate) as? Date else {
            // First time loading
            defaults.set(Date(), forKey: Constants.UserDefaultsKeys.lastActiveDate)
            defaults.set(1, forKey: Constants.UserDefaultsKeys.currentStreak)
            self.currentStreak = 1
            return
        }
        
        if calendar.isDateInToday(lastActiveDate) {
            // Already logged in today, streak stays the same
            return
        } else if calendar.isDateInYesterday(lastActiveDate) {
            // Increment streak
            let streak = defaults.integer(forKey: Constants.UserDefaultsKeys.currentStreak) + 1
            defaults.set(Date(), forKey: Constants.UserDefaultsKeys.lastActiveDate)
            defaults.set(streak, forKey: Constants.UserDefaultsKeys.currentStreak)
            self.currentStreak = streak
        } else {
            // Streak broken
            defaults.set(Date(), forKey: Constants.UserDefaultsKeys.lastActiveDate)
            defaults.set(1, forKey: Constants.UserDefaultsKeys.currentStreak)
            self.currentStreak = 1
        }
    }
    
    func updateReadingGoal(_ newGoal: Int) {
        let clampedGoal = max(5, min(120, newGoal))
        self.readingGoal = clampedGoal
        UserDefaults.standard.set(clampedGoal, forKey: Constants.UserDefaultsKeys.dailyReadingGoalMinutes)
    }
}
