import Foundation
import Combine
import Speech

@MainActor
final class PracticeViewModel: ObservableObject {
    let targetWord: String
    
    @Published var isRecording = false
    @Published var transcription = ""
    @Published var score: Double? = nil
    @Published var feedbackMessage = ""
    @Published var errorMessage: String? = nil
    
    private let speechManager = SpeechManager.shared
    private let coreData = CoreDataManager.shared
    private var cancellables = Set<AnyCancellable>()
    
    init(word: String) {
        self.targetWord = word.trimmingCharacters(in: .whitespacesAndNewlines)
        setupSpeechBindings()
    }
    
    private func setupSpeechBindings() {
        speechManager.$isRecording
            .receive(on: DispatchQueue.main)
            .sink { [weak self] val in self?.isRecording = val }
            .store(in: &cancellables)
            
        speechManager.$transcribedText
            .receive(on: DispatchQueue.main)
            .sink { [weak self] text in
                self?.transcription = text
            }
            .store(in: &cancellables)
    }
    
    func toggleRecording() async {
        if isRecording {
            stopRecordingAndEvaluate()
        } else {
            await startRecording()
        }
    }
    
    func startRecording() async {
        errorMessage = nil
        score = nil
        transcription = ""
        feedbackMessage = ""
        
        let micGranted = await speechManager.requestMicPermission()
        guard micGranted else {
            errorMessage = "Microphone access is required to practice pronunciation."
            HapticManager.shared.triggerNotification(type: .error)
            return
        }
        
        do {
            HapticManager.shared.triggerHeavy()
            try speechManager.startRecording()
        } catch {
            errorMessage = "Could not initialize speech recognition: \(error.localizedDescription)"
            HapticManager.shared.triggerNotification(type: .error)
        }
    }
    
    func stopRecordingAndEvaluate() {
        HapticManager.shared.triggerMedium()
        speechManager.stopRecording()
        
        // Wait a split second for final transcription updates to settle
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self] in
            guard let self = self else { return }
            self.evaluateScore()
        }
    }
    
    private func evaluateScore() {
        let textToCompare = transcription.trimmingCharacters(in: .whitespacesAndNewlines)
        
        guard !textToCompare.isEmpty else {
            self.score = 0.0
            self.feedbackMessage = "We couldn't hear anything. Please try again!"
            HapticManager.shared.triggerNotification(type: .warning)
            return
        }
        
        let calculatedScore = targetWord.similarity(to: textToCompare)
        self.score = calculatedScore
        
        // Generate feedback string based on score
        if calculatedScore >= 90.0 {
            self.feedbackMessage = "Excellent! You sound like a native speaker!"
            HapticManager.shared.triggerNotification(type: .success)
        } else if calculatedScore >= 75.0 {
            self.feedbackMessage = "Great job! Your pronunciation is very clear."
            HapticManager.shared.triggerNotification(type: .success)
        } else if calculatedScore >= 50.0 {
            self.feedbackMessage = "Good effort! Let's listen to the model and try again."
            HapticManager.shared.triggerNotification(type: .warning)
        } else {
            self.feedbackMessage = "Keep practicing! Tap the ear icon to listen closely."
            HapticManager.shared.triggerNotification(type: .warning)
        }
        
        // Save the pronunciation score in Core Data
        saveScore(calculatedScore)
    }
    
    private func saveScore(_ calculatedScore: Double) {
        // Find or create word in local storage to bind scores
        let word = coreData.addWordToBasket(text: targetWord, meaning: nil, difficulty: "Medium")
        coreData.recordPronunciationScore(for: word, score: calculatedScore, audioPath: nil)
    }
    
    func playModelPronunciation() {
        speechManager.speak(text: targetWord, rate: 0.7)
    }
}
