import Foundation
import Combine
import CoreData

@MainActor
final class WordBasketViewModel: ObservableObject {
    @Published var words: [CDWord] = []
    @Published var difficultyFilter: String = "All" // "All", "Easy", "Medium", "Hard"
    @Published var sortOption: String = "Newest"      // "Newest", "Alphabetical", "Score"
    
    private let coreData = CoreDataManager.shared
    
    init() {
        fetchWords()
    }
    
    func fetchWords() {
        var fetched = coreData.fetchWords()
        
        // 1. Filter by difficulty
        if difficultyFilter != "All" {
            fetched = fetched.filter { $0.difficulty == difficultyFilter }
        }
        
        // 2. Sort words
        switch sortOption {
        case "Alphabetical":
            fetched.sort { ($0.text ?? "").lowercased() < ($1.text ?? "").lowercased() }
        case "Score":
            // Sort by average score descending (words with highest average score first)
            fetched.sort { $0.averageScore > $1.averageScore }
        default: // Newest
            fetched.sort { ($0.createdAt ?? Date()) > ($1.createdAt ?? Date()) }
        }
        
        self.words = fetched
    }
    
    func deleteWord(_ word: CDWord) {
        coreData.deleteWord(word)
        fetchWords()
    }
    
    func updateWordDifficulty(_ word: CDWord, to newDifficulty: String) {
        word.difficulty = newDifficulty
        coreData.saveContext()
        fetchWords()
    }
}
