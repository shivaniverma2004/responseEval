import UIKit
import Combine
import CoreData

@MainActor
final class ProjectViewModel: ObservableObject {
    @Published var projects: [CDProject] = []
    @Published var isLoading = false
    
    // Staging list for camera/gallery imports before saving/reading
    @Published var stagedImages: [UIImage] = []
    @Published var stagedExtractedText = ""
    
    private let coreData = CoreDataManager.shared
    private let ocrManager = OCRManager.shared
    
    init() {
        fetchProjects()
    }
    
    func fetchProjects() {
        self.projects = coreData.fetchProjects()
    }
    
    // MARK: - Project CRUD
    
    func createProject(name: String) -> CDProject {
        let newProject = coreData.createProject(name: name)
        fetchProjects()
        return newProject
    }
    
    func renameProject(_ project: CDProject, to newName: String) {
        coreData.renameProject(project, to: newName)
        fetchProjects()
    }
    
    func deleteProject(_ project: CDProject) {
        coreData.deleteProject(project)
        fetchProjects()
    }
    
    // MARK: - Image Operations
    
    func addImagesToProject(project: CDProject, uiImages: [UIImage]) async {
        isLoading = true
        for image in uiImages {
            if let rawData = image.jpegData(compressionQuality: 0.8) {
                // Perform OCR first to save it
                let text = await ocrManager.extractText(from: [image])
                _ = coreData.addImageToProject(project: project, rawData: rawData, extractedText: text)
            }
        }
        coreData.saveContext()
        fetchProjects()
        isLoading = false
    }
    
    func deleteImageFromProject(_ image: CDImage) {
        coreData.deleteImage(image)
        fetchProjects()
    }
    
    // MARK: - Staging & Direct Processing Operations
    
    func stageImages(_ images: [UIImage]) {
        self.stagedImages.append(contentsOf: images)
    }
    
    func removeStagedImage(at index: Int) {
        guard stagedImages.indices.contains(index) else { return }
        stagedImages.remove(at: index)
    }
    
    func clearStaging() {
        stagedImages.removeAll()
        stagedExtractedText = ""
    }
    
    /// Run OCR on staged images directly without saving.
    func processStagedOCRDirectly() async -> String {
        guard !stagedImages.isEmpty else { return "" }
        isLoading = true
        let text = await ocrManager.extractText(from: stagedImages)
        self.stagedExtractedText = text
        isLoading = false
        return text
    }
    
    /// Save staged images to a project and run OCR.
    func saveStagedToProject(name: String) async -> CDProject {
        isLoading = true
        let project = createProject(name: name)
        await addImagesToProject(project: project, uiImages: stagedImages)
        clearStaging()
        isLoading = false
        return project
    }
    
    /// Save staged images to an existing project.
    func saveStagedToExistingProject(_ project: CDProject) async {
        isLoading = true
        await addImagesToProject(project: project, uiImages: stagedImages)
        clearStaging()
        isLoading = false
    }
}
