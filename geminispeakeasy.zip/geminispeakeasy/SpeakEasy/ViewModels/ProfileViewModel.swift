import Foundation
import Combine
import CoreData

@MainActor
final class ProfileViewModel: ObservableObject {
    @Published var userName = "Guest"
    @Published var userEmail = ""
    @Published var totalProjects = 0
    @Published var totalWords = 0
    @Published var totalPracticeSessions = 0
    @Published var averagePronunciationScore = 0.0
    
    private let coreData = CoreDataManager.shared
    
    init() {
        fetchProfileStats()
    }
    
    func fetchProfileStats() {
        let defaults = UserDefaults.standard
        self.userName = defaults.string(forKey: Constants.UserDefaultsKeys.userName) ?? "Guest"
        self.userEmail = defaults.string(forKey: Constants.UserDefaultsKeys.userEmail) ?? "Guest Mode Enabled"
        
        let allProjects = coreData.fetchProjects()
        self.totalProjects = allProjects.count
        
        let allWords = coreData.fetchWords()
        self.totalWords = allWords.count
        
        // Calculate totals across all saved word scores
        var practiceCount = 0
        var scoreSum = 0.0
        
        for word in allWords {
            let scores = word.scoresArray
            practiceCount += scores.count
            scoreSum += scores.reduce(0.0) { $0 + $1.score }
        }
        
        self.totalPracticeSessions = practiceCount
        self.averagePronunciationScore = practiceCount > 0 ? (scoreSum / Double(practiceCount)) : 0.0
    }
}
