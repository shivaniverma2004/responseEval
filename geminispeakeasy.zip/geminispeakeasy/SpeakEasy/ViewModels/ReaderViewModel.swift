import SwiftUI
import Combine

struct ReaderWord: Identifiable, Equatable {
    let id = UUID()
    let rawText: String   // Includes punctuation for layout rendering
    let cleanText: String // Stripped of punctuation for dictionary and voice tests
}

@MainActor
final class ReaderViewModel: ObservableObject {
    @Published var originalText: String = ""
    @Published var words: [ReaderWord] = []
    
    // Layout and Theme Config
    @Published var layoutConfig = ReaderLayoutConfig()
    
    // Speech states (proxies from SpeechManager)
    @Published var isSpeaking = false
    @Published var isPaused = false
    @Published var speechRate: Float = 1.0 // speed factor: 0.5 to 2.0
    
    // AI (Gemini) states
    @Published var isProcessingAI = false
    @Published var aiResultTitle = ""
    @Published var aiResultText: String? = nil
    @Published var quizQuestions: [QuizQuestion] = []
    
    // Selected word states
    @Published var selectedWord: ReaderWord? = nil
    @Published var isLookingUpWord = false
    @Published var selectedWordDetails: WordDetails? = nil
    
    private let speechManager = SpeechManager.shared
    private let gemini = GeminiManager.shared
    private let dictionary = DictionaryManager.shared
    private let coreData = CoreDataManager.shared
    
    private var cancellables = Set<AnyCancellable>()
    
    init(text: String = "") {
        setText(text)
        setupSpeechBindings()
    }
    
    func setText(_ text: String) {
        self.originalText = text
        
        guard !text.isEmpty else {
            self.words = []
            return
        }
        
        // Tokenize text into words, retaining punctuation
        let rawTokens = text.components(separatedBy: .whitespacesAndNewlines)
        self.words = rawTokens.filter { !$0.isEmpty }.map { token in
            // Clean word: remove non-alphanumeric (like commas, periods, quotes)
            let cleaned = token.components(separatedBy: CharacterSet.alphanumerics.inverted).joined()
            return ReaderWord(rawText: token, cleanText: cleaned)
        }
    }
    
    private func setupSpeechBindings() {
        // Bind TTS state updates
        speechManager.$isSpeaking
            .receive(on: DispatchQueue.main)
            .sink { [weak self] val in self?.isSpeaking = val }
            .store(in: &cancellables)
            
        speechManager.$isPaused
            .receive(on: DispatchQueue.main)
            .sink { [weak self] val in self?.isPaused = val }
            .store(in: &cancellables)
    }
    
    // MARK: - Text-To-Speech Controls
    
    func toggleReadAloud() {
        if isSpeaking {
            if isPaused {
                speechManager.resumeSpeaking()
            } else {
                speechManager.pauseSpeaking()
            }
        } else {
            guard !originalText.isEmpty else { return }
            speechManager.speak(text: originalText, rate: speechRate)
        }
    }
    
    func stopReadAloud() {
        speechManager.stopSpeaking()
    }
    
    func updateSpeechRate(_ rate: Float) {
        self.speechRate = rate
        if isSpeaking && !isPaused {
            // Restart audio stream at new speed rate
            speechManager.speak(text: originalText, rate: speechRate)
        }
    }
    
    // MARK: - AI Functions (Gemini)
    
    func runAISummarize() async {
        guard !originalText.isEmpty else { return }
        prepareAIAction(title: "AI Summary")
        do {
            let summary = try await gemini.summarize(text: originalText)
            self.aiResultText = summary
            coreData.logActivity(type: "ai", details: "Generated AI summary")
        } catch {
            self.aiResultText = "AI Request Failed: \(error.localizedDescription)"
        }
        isProcessingAI = false
    }
    
    func runAISimplify() async {
        guard !originalText.isEmpty else { return }
        prepareAIAction(title: "AI Simplification")
        do {
            let simplified = try await gemini.simplify(text: originalText)
            self.aiResultText = simplified
            coreData.logActivity(type: "ai", details: "Simplified reading level")
        } catch {
            self.aiResultText = "AI Request Failed: \(error.localizedDescription)"
        }
        isProcessingAI = false
    }
    
    func runAIGrammar() async {
        guard !originalText.isEmpty else { return }
        prepareAIAction(title: "AI Grammar Guide")
        do {
            let grammar = try await gemini.explainGrammar(text: originalText)
            self.aiResultText = grammar
            coreData.logActivity(type: "ai", details: "Analyzed reading grammar")
        } catch {
            self.aiResultText = "AI Request Failed: \(error.localizedDescription)"
        }
        isProcessingAI = false
    }
    
    func runAIGenerateQuiz() async {
        guard !originalText.isEmpty else { return }
        prepareAIAction(title: "Comprehension Quiz")
        do {
            let questions = try await gemini.generateQuiz(text: originalText)
            self.quizQuestions = questions
            self.aiResultText = "Quiz loaded. Please answer the questions below."
            coreData.logActivity(type: "ai", details: "Generated quiz selection")
        } catch {
            self.aiResultText = "Failed to load quiz: \(error.localizedDescription)"
        }
        isProcessingAI = false
    }
    
    private func prepareAIAction(title: String) {
        isProcessingAI = true
        aiResultTitle = title
        aiResultText = nil
        quizQuestions = []
    }
    
    func clearAIResult() {
        aiResultText = nil
        quizQuestions = []
        aiResultTitle = ""
    }
    
    // MARK: - Word Operations (Dictionary lookup & Basket saving)
    
    func selectWord(_ word: ReaderWord) async {
        self.selectedWord = word
        self.selectedWordDetails = nil
        self.isLookingUpWord = true
        
        HapticManager.shared.triggerLight()
        
        do {
            let details = try await dictionary.lookupWord(word.cleanText)
            self.selectedWordDetails = details
        } catch {
            // Use fallback details on failure
            self.selectedWordDetails = WordDetails(
                word: word.cleanText,
                phonetic: "/\(word.cleanText)/",
                audioURL: nil,
                definitions: ["Meaning lookup failed: \(error.localizedDescription)"]
            )
        }
        
        self.isLookingUpWord = false
    }
    
    func addSelectedWordToBasket(difficulty: String = "Medium") {
        guard let word = selectedWord, let details = selectedWordDetails else { return }
        let meaningText = details.definitions.joined(separator: "\n")
        _ = coreData.addWordToBasket(text: word.cleanText, meaning: meaningText, difficulty: difficulty)
        HapticManager.shared.triggerNotification(type: .success)
    }
    
    func playSelectedWordAudio() {
        guard let details = selectedWordDetails, let audioURL = details.audioURL else {
            // Speak using local TTS instead if audio URL is missing
            if let word = selectedWord {
                speechManager.speak(text: word.cleanText, rate: 0.8)
            }
            return
        }
        
        // Play phonetic URL using AVPlayer
        let player = AVPlayer(url: audioURL)
        player.play()
        HapticManager.shared.triggerLight()
    }
}
