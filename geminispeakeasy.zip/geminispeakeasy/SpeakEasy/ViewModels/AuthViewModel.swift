import Foundation
import Combine

@MainActor
final class AuthViewModel: ObservableObject {
    @Published var email = ""
    @Published var password = ""
    @Published var fullName = ""
    
    @Published var isLoading = false
    @Published var errorMessage: String? = nil
    
    @Published var isUserLoggedIn = false
    @Published var isGuestMode = false
    @Published var currentUserName = "Guest"
    @Published var currentUserEmail = ""
    
    private let supabase = SupabaseManager.shared
    
    init() {
        checkExistingSession()
    }
    
    func checkExistingSession() {
        let defaults = UserDefaults.standard
        let loggedIn = defaults.bool(forKey: Constants.UserDefaultsKeys.isUserLoggedIn)
        let guest = defaults.bool(forKey: Constants.UserDefaultsKeys.isGuestMode)
        
        if loggedIn {
            self.isUserLoggedIn = true
            self.isGuestMode = false
            self.currentUserName = defaults.string(forKey: Constants.UserDefaultsKeys.userName) ?? "Learner"
            self.currentUserEmail = defaults.string(forKey: Constants.UserDefaultsKeys.userEmail) ?? ""
        } else if guest {
            self.isUserLoggedIn = false
            self.isGuestMode = true
            self.currentUserName = "Guest"
            self.currentUserEmail = ""
        } else {
            self.isUserLoggedIn = false
            self.isGuestMode = false
            self.currentUserName = "Guest"
            self.currentUserEmail = ""
        }
    }
    
    func login() async {
        guard validateLoginInputs() else { return }
        
        isLoading = true
        errorMessage = nil
        
        do {
            let (_, name) = try await supabase.signIn(email: email, password: password)
            self.isUserLoggedIn = true
            self.isGuestMode = false
            self.currentUserName = name
            self.currentUserEmail = email
            
            // Log authentication activity
            CoreDataManager.shared.logActivity(type: "auth", details: "Logged in as \(email)")
            clearInputs()
        } catch {
            errorMessage = error.localizedDescription
            HapticManager.shared.triggerNotification(type: .error)
        }
        
        isLoading = false
    }
    
    func signUp() async {
        guard validateSignUpInputs() else { return }
        
        isLoading = true
        errorMessage = nil
        
        do {
            _ = try await supabase.signUp(email: email, password: password, fullName: fullName)
            // Log signup activity
            CoreDataManager.shared.logActivity(type: "auth", details: "Registered user \(email)")
            
            // Auto login after signup
            await login()
        } catch {
            errorMessage = error.localizedDescription
            HapticManager.shared.triggerNotification(type: .error)
        }
        
        isLoading = false
    }
    
    func continueAsGuest() {
        let defaults = UserDefaults.standard
        defaults.set(false, forKey: Constants.UserDefaultsKeys.isUserLoggedIn)
        defaults.set(true, forKey: Constants.UserDefaultsKeys.isGuestMode)
        defaults.set("Guest", forKey: Constants.UserDefaultsKeys.userName)
        
        self.isUserLoggedIn = false
        self.isGuestMode = true
        self.currentUserName = "Guest"
        self.currentUserEmail = ""
        
        CoreDataManager.shared.logActivity(type: "auth", details: "Continued as Guest")
        clearInputs()
    }
    
    func logout() async {
        let defaults = UserDefaults.standard
        let token = defaults.string(forKey: Constants.UserDefaultsKeys.userSessionToken) ?? ""
        
        isLoading = true
        
        if !token.isEmpty {
            await supabase.signOut(token: token)
        } else {
            // Simply clean local keys if token empty
            defaults.set(false, forKey: Constants.UserDefaultsKeys.isUserLoggedIn)
            defaults.set(false, forKey: Constants.UserDefaultsKeys.isGuestMode)
            defaults.removeObject(forKey: Constants.UserDefaultsKeys.userSessionToken)
            defaults.removeObject(forKey: Constants.UserDefaultsKeys.userEmail)
            defaults.removeObject(forKey: Constants.UserDefaultsKeys.userName)
        }
        
        self.isUserLoggedIn = false
        self.isGuestMode = false
        self.currentUserName = "Guest"
        self.currentUserEmail = ""
        
        isLoading = false
        HapticManager.shared.triggerNotification(type: .success)
    }
    
    // MARK: - Validation Utilities
    
    private func validateLoginInputs() -> Bool {
        if email.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            errorMessage = "Please enter your email address."
            return false
        }
        if password.isEmpty {
            errorMessage = "Please enter your password."
            return false
        }
        return true
    }
    
    private func validateSignUpInputs() -> Bool {
        if fullName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            errorMessage = "Please enter your full name."
            return false
        }
        if email.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            errorMessage = "Please enter your email address."
            return false
        }
        if password.count < 6 {
            errorMessage = "Password must be at least 6 characters long."
            return false
        }
        return true
    }
    
    private func clearInputs() {
        email = ""
        password = ""
        fullName = ""
        errorMessage = nil
    }
}
