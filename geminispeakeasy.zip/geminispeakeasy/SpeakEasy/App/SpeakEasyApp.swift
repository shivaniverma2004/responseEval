import SwiftUI

@main
struct SpeakEasyApp: App {
    // Instantiate persistent container
    private let coreDataManager = CoreDataManager.shared
    
    @StateObject private var authViewModel = AuthViewModel()
    
    var body: some Scene {
        WindowGroup {
            Group {
                if authViewModel.isUserLoggedIn || authViewModel.isGuestMode {
                    MainTabView()
                        .environment(\.managedObjectContext, coreDataManager.viewContext)
                        .environmentObject(authViewModel)
                        .transition(.asymmetric(
                            insertion: .move(edge: .trailing).combined(with: .opacity),
                            removal: .move(edge: .leading).combined(with: .opacity)
                        ))
                } else {
                    LoginView()
                        .environmentObject(authViewModel)
                        .transition(.asymmetric(
                            insertion: .move(edge: .leading).combined(with: .opacity),
                            removal: .move(edge: .trailing).combined(with: .opacity)
                        ))
                }
            }
            .animation(.spring(response: 0.45, dampingFraction: 0.82), value: authViewModel.isUserLoggedIn || authViewModel.isGuestMode)
        }
    }
}
