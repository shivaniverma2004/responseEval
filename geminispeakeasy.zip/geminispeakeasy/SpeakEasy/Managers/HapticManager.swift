import UIKit

final class HapticManager {
    static let shared = HapticManager()
    
    private init() {}
    
    /// Trigger light impact feedback (good for word selection/taps).
    func triggerLight() {
        let generator = UIImpactFeedbackGenerator(style: .light)
        generator.prepare()
        generator.impactOccurred()
    }
    
    /// Trigger medium impact feedback (good for button selections).
    func triggerMedium() {
        let generator = UIImpactFeedbackGenerator(style: .medium)
        generator.prepare()
        generator.impactOccurred()
    }
    
    /// Trigger heavy impact feedback (good for core actions like starting recording).
    func triggerHeavy() {
        let generator = UIImpactFeedbackGenerator(style: .heavy)
        generator.prepare()
        generator.impactOccurred()
    }
    
    /// Trigger notification feedback (success, warning, or error).
    func triggerNotification(type: UINotificationFeedbackGenerator.FeedbackType) {
        let generator = UINotificationFeedbackGenerator()
        generator.prepare()
        generator.notificationOccurred(type)
    }
}
