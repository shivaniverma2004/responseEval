import CoreData
import UIKit

final class CoreDataManager {
    static let shared = CoreDataManager()
    
    let persistentContainer: NSPersistentContainer
    
    var viewContext: NSManagedObjectContext {
        persistentContainer.viewContext
    }
    
    private init() {
        persistentContainer = NSPersistentContainer(name: "SpeakEasy")
        persistentContainer.loadPersistentStores { description, error in
            if let error = error as NSError? {
                // In production, handle this gracefully
                print("FATAL ERROR: Failed to load Core Data Stack: \(error), \(error.userInfo)")
            }
        }
        
        // Configure context for optimization
        viewContext.automaticallyMergesChangesFromParent = true
        viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
    }
    
    func saveContext() {
        let context = viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                print("CoreData Save Error: \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    // MARK: - CDProject Operations
    
    func fetchProjects() -> [CDProject] {
        let request: NSFetchRequest<CDProject> = NSFetchRequest<CDProject>(entityName: "CDProject")
        request.sortDescriptors = [NSSortDescriptor(keyPath: \CDProject.createdAt, ascending: false)]
        do {
            return try viewContext.fetch(request)
        } catch {
            print("Fetch projects failed: \(error)")
            return []
        }
    }
    
    func createProject(name: String) -> CDProject {
        let project = CDProject(context: viewContext)
        project.id = UUID()
        project.name = name
        project.createdAt = Date()
        saveContext()
        logActivity(type: "project", details: "Created project '\(name)'")
        return project
    }
    
    func renameProject(_ project: CDProject, to newName: String) {
        project.name = newName
        saveContext()
    }
    
    func deleteProject(_ project: CDProject) {
        let name = project.name ?? "Unnamed"
        viewContext.delete(project)
        saveContext()
        logActivity(type: "project", details: "Deleted project '\(name)'")
    }
    
    // MARK: - CDImage Operations
    
    func addImageToProject(project: CDProject?, rawData: Data, extractedText: String?) -> CDImage {
        let image = CDImage(context: viewContext)
        image.id = UUID()
        image.imageData = rawData
        image.extractedText = extractedText
        image.createdAt = Date()
        if let project = project {
            image.project = project
        }
        saveContext()
        return image
    }
    
    func deleteImage(_ image: CDImage) {
        viewContext.delete(image)
        saveContext()
    }
    
    // MARK: - CDWord Operations
    
    func fetchWords() -> [CDWord] {
        let request: NSFetchRequest<CDWord> = NSFetchRequest<CDWord>(entityName: "CDWord")
        request.sortDescriptors = [NSSortDescriptor(keyPath: \CDWord.createdAt, ascending: false)]
        do {
            return try viewContext.fetch(request)
        } catch {
            print("Fetch words failed: \(error)")
            return []
        }
    }
    
    func addWordToBasket(text: String, meaning: String?, difficulty: String = "Medium") -> CDWord {
        // Prevent duplication: check if word already exists
        let request: NSFetchRequest<CDWord> = NSFetchRequest<CDWord>(entityName: "CDWord")
        request.predicate = NSPredicate(format: "text ==[c] %@", text)
        
        if let existingWord = try? viewContext.fetch(request).first {
            // Update meaning or difficulty if needed, but return existing
            if let meaning = meaning {
                existingWord.meaning = meaning
            }
            existingWord.difficulty = difficulty
            saveContext()
            return existingWord
        }
        
        let word = CDWord(context: viewContext)
        word.id = UUID()
        word.text = text
        word.meaning = meaning
        word.difficulty = difficulty
        word.createdAt = Date()
        
        saveContext()
        logActivity(type: "word", details: "Added '\(text)' to word basket")
        return word
    }
    
    func deleteWord(_ word: CDWord) {
        let text = word.text ?? ""
        viewContext.delete(word)
        saveContext()
        logActivity(type: "word", details: "Removed '\(text)' from basket")
    }
    
    // MARK: - Pronunciation Score Operations
    
    func recordPronunciationScore(for word: CDWord, score: Double, audioPath: String?) {
        let record = CDPronunciationScore(context: viewContext)
        record.id = UUID()
        record.score = score
        record.date = Date()
        record.audioPath = audioPath
        record.word = word
        
        saveContext()
        logActivity(type: "practice", details: "Practiced '\(word.text ?? "")' - Score: \(Int(score))%")
    }
    
    // MARK: - CDActivity Log Operations
    
    func fetchActivities(limit: Int = 10) -> [CDActivity] {
        let request: NSFetchRequest<CDActivity> = NSFetchRequest<CDActivity>(entityName: "CDActivity")
        request.sortDescriptors = [NSSortDescriptor(keyPath: \CDActivity.date, ascending: false)]
        request.fetchLimit = limit
        do {
            return try viewContext.fetch(request)
        } catch {
            print("Fetch activities failed: \(error)")
            return []
        }
    }
    
    func logActivity(type: String, details: String) {
        let activity = CDActivity(context: viewContext)
        activity.id = UUID()
        activity.type = type
        activity.details = details
        activity.date = Date()
        saveContext()
    }
}

// MARK: - Core Data Generated Classes Stubs
// These classes provide type compatibility for standard Xcode compilation since the data model defines them.
@objc(CDProject)
public class CDProject: NSManagedObject {}

extension CDProject {
    @NSManaged public var id: UUID?
    @NSManaged public var name: String?
    @NSManaged public var createdAt: Date?
    @NSManaged public var images: NSSet?
    
    public var imageArray: [CDImage] {
        let set = images as? Set<CDImage> ?? []
        return set.sorted { ($0.createdAt ?? Date()) < ($1.createdAt ?? Date()) }
    }
}

@objc(CDImage)
public class CDImage: NSManagedObject {}

extension CDImage {
    @NSManaged public var id: UUID?
    @NSManaged public var imageData: Data?
    @NSManaged public var extractedText: String?
    @NSManaged public var createdAt: Date?
    @NSManaged public var project: CDProject?
}

@objc(CDWord)
public class CDWord: NSManagedObject {}

extension CDWord {
    @NSManaged public var id: UUID?
    @NSManaged public var text: String?
    @NSManaged public var meaning: String?
    @NSManaged public var difficulty: String?
    @NSManaged public var createdAt: Date?
    @NSManaged public var scores: NSSet?
    
    public var scoresArray: [CDPronunciationScore] {
        let set = scores as? Set<CDPronunciationScore> ?? []
        return set.sorted { ($0.date ?? Date()) > ($1.date ?? Date()) }
    }
    
    public var averageScore: Double {
        let arr = scoresArray
        guard !arr.isEmpty else { return 0.0 }
        let total = arr.reduce(0.0) { $0 + $1.score }
        return total / Double(arr.count)
    }
}

@objc(CDPronunciationScore)
public class CDPronunciationScore: NSManagedObject {}

extension CDPronunciationScore {
    @NSManaged public var id: UUID?
    @NSManaged public var score: Double
    @NSManaged public var date: Date?
    @NSManaged public var audioPath: String?
    @NSManaged public var word: CDWord?
}

@objc(CDActivity)
public class CDActivity: NSManagedObject {}

extension CDActivity {
    @NSManaged public var id: UUID?
    @NSManaged public var type: String?
    @NSManaged public var details: String?
    @NSManaged public var date: Date?
}
