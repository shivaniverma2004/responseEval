import UIKit
import Vision

final class OCRManager {
    static let shared = OCRManager()
    
    private init() {}
    
    /// Extracts text from a collection of UIImages asynchronously.
    func extractText(from images: [UIImage]) async -> String {
        var combinedText = ""
        
        for (index, image) in images.enumerated() {
            let pageText = await performOCROnImage(image)
            
            if !pageText.isEmpty {
                if index > 0 {
                    combinedText += "\n\n--- Page \(index + 1) ---\n\n"
                }
                combinedText += pageText
            }
        }
        
        return combinedText.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    private func performOCROnImage(_ image: UIImage) async -> String {
        guard let cgImage = image.cgImage else { return "" }
        
        return await withCheckedContinuation { continuation in
            let request = VNRecognizeTextRequest { request, error in
                guard error == nil else {
                    print("OCR Vision Request Error: \(error!.localizedDescription)")
                    continuation.resume(returning: "")
                    return
                }
                
                guard let observations = request.results as? [VNRecognizedTextObservation] else {
                    continuation.resume(returning: "")
                    return
                }
                
                // Sort observations vertically then horizontally (top-to-bottom, left-to-right reading order)
                let sortedObservations = observations.sorted {
                    let box1 = $0.boundingBox
                    let box2 = $1.boundingBox
                    if abs(box1.origin.y - box2.origin.y) > 0.05 {
                        return box1.origin.y > box2.origin.y // top down
                    }
                    return box1.origin.x < box2.origin.x // left to right
                }
                
                var extractedLines: [String] = []
                for observation in sortedObservations {
                    // Extract the top candidate translation string
                    if let candidate = observation.topCandidates(1).first {
                        extractedLines.append(candidate.string)
                    }
                }
                
                let resultText = extractedLines.joined(separator: "\n")
                continuation.resume(returning: resultText)
            }
            
            // Configure the text recognition request settings
            request.recognitionLevel = .accurate
            request.recognitionLanguages = ["en-US", "en-GB"]
            request.usesLanguageCorrection = true
            
            // Create VNImageRequestHandler
            let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
            
            DispatchQueue.global(qos: .userInitiated).async {
                do {
                    try handler.perform([request])
                } catch {
                    print("OCR handler failed: \(error)")
                    continuation.resume(returning: "")
                }
            }
        }
    }
}
