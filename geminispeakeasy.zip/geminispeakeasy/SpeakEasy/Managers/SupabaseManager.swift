import Foundation

enum SupabaseError: LocalizedError {
    case invalidURL
    case badRequest(String)
    case invalidResponse
    case decodingError
    case unauthorized
    
    var errorDescription: String? {
        switch self {
        case .invalidURL: return "Invalid Supabase Endpoint configuration."
        case .badRequest(let message): return message
        case .invalidResponse: return "Received invalid response from server."
        case .decodingError: return "Failed to process server authentication data."
        case .unauthorized: return "Invalid email or password."
        }
    }
}

final class SupabaseManager {
    static let shared = SupabaseManager()
    
    private let session = URLSession.shared
    private let baseURL: URL
    private let anonKey: String
    
    private init() {
        self.baseURL = Config.supabaseURL
        self.anonKey = Config.supabaseAnonKey
    }
    
    private var commonHeaders: [String: String] {
        return [
            "apikey": anonKey,
            "Authorization": "Bearer \(anonKey)",
            "Content-Type": "application/json"
        ]
    }
    
    // MARK: - Sign Up
    func signUp(email: String, password: String, fullName: String) async throws -> String {
        let signUpURL = baseURL.appendingPathComponent("auth/v1/signup")
        
        var request = URLRequest(url: signUpURL)
        request.httpMethod = "POST"
        commonHeaders.forEach { request.setValue($1, forHTTPHeaderField: $0) }
        
        let body: [String: Any] = [
            "email": email,
            "password": password,
            "data": [
                "full_name": fullName
            ]
        ]
        
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        let (data, response) = try await session.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            throw SupabaseError.invalidResponse
        }
        
        if !(200...299).contains(httpResponse.statusCode) {
            let errorMsg = parseErrorMessage(data: data)
            throw SupabaseError.badRequest(errorMsg)
        }
        
        // Parse user verification status or session details
        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let user = json["user"] as? [String: Any] else {
            throw SupabaseError.decodingError
        }
        
        return user["id"] as? String ?? ""
    }
    
    // MARK: - Sign In
    func signIn(email: String, password: String) async throws -> (token: String, name: String) {
        let signInURL = baseURL.appendingPathComponent("auth/v1/token")
        var urlComponents = URLComponents(url: signInURL, resolvingAgainstBaseURL: true)
        urlComponents?.queryItems = [URLQueryItem(name: "grant_type", value: "password")]
        
        guard let finalURL = urlComponents?.url else {
            throw SupabaseError.invalidURL
        }
        
        var request = URLRequest(url: finalURL)
        request.httpMethod = "POST"
        commonHeaders.forEach { request.setValue($1, forHTTPHeaderField: $0) }
        
        let body = [
            "email": email,
            "password": password
        ]
        
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        let (data, response) = try await session.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            throw SupabaseError.invalidResponse
        }
        
        if httpResponse.statusCode == 400 || httpResponse.statusCode == 401 {
            throw SupabaseError.unauthorized
        }
        
        if !(200...299).contains(httpResponse.statusCode) {
            let errorMsg = parseErrorMessage(data: data)
            throw SupabaseError.badRequest(errorMsg)
        }
        
        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let token = json["access_token"] as? String,
              let user = json["user"] as? [String: Any] else {
            throw SupabaseError.decodingError
        }
        
        let metadata = user["user_metadata"] as? [String: Any]
        let name = metadata?["full_name"] as? String ?? "User"
        
        // Save Session Details locally
        UserDefaults.standard.set(true, forKey: Constants.UserDefaultsKeys.isUserLoggedIn)
        UserDefaults.standard.set(false, forKey: Constants.UserDefaultsKeys.isGuestMode)
        UserDefaults.standard.set(token, forKey: Constants.UserDefaultsKeys.userSessionToken)
        UserDefaults.standard.set(email, forKey: Constants.UserDefaultsKeys.userEmail)
        UserDefaults.standard.set(name, forKey: Constants.UserDefaultsKeys.userName)
        
        return (token, name)
    }
    
    // MARK: - Sign Out
    func signOut(token: String) async {
        let signOutURL = baseURL.appendingPathComponent("auth/v1/logout")
        
        var request = URLRequest(url: signOutURL)
        request.httpMethod = "POST"
        commonHeaders.forEach { request.setValue($1, forHTTPHeaderField: $0) }
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        
        _ = try? await session.data(for: request)
        
        // Clean session details
        UserDefaults.standard.set(false, forKey: Constants.UserDefaultsKeys.isUserLoggedIn)
        UserDefaults.standard.set(false, forKey: Constants.UserDefaultsKeys.isGuestMode)
        UserDefaults.standard.removeObject(forKey: Constants.UserDefaultsKeys.userSessionToken)
        UserDefaults.standard.removeObject(forKey: Constants.UserDefaultsKeys.userEmail)
        UserDefaults.standard.removeObject(forKey: Constants.UserDefaultsKeys.userName)
    }
    
    // MARK: - Utility Error Parsing
    private func parseErrorMessage(data: Data) -> String {
        if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            if let desc = json["error_description"] as? String {
                return desc
            }
            if let msg = json["msg"] as? String {
                return msg
            }
            if let msg = json["message"] as? String {
                return msg
            }
        }
        return "Unknown authentication error occurred."
    }
}
