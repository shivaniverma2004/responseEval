import Foundation

struct DictionaryEntry: Decodable {
    let word: String
    let phonetic: String?
    let phonetics: [PhoneticEntry]?
    let meanings: [MeaningEntry]?
}

struct PhoneticEntry: Decodable {
    let text: String?
    let audio: String?
}

struct MeaningEntry: Decodable {
    let partOfSpeech: String
    let definitions: [DefinitionItem]
}

struct DefinitionItem: Decodable {
    let definition: String
    let example: String?
}

// App Domain Model
struct WordDetails: Identifiable {
    let id = UUID()
    let word: String
    let phonetic: String
    let audioURL: URL?
    let definitions: [String] // formatted as ["noun: definition (e.g. example)", ...]
}

final class DictionaryManager {
    static let shared = DictionaryManager()
    
    private let session = URLSession.shared
    
    private init() {}
    
    func lookupWord(_ word: String) async throws -> WordDetails {
        let cleanedWord = word.trimmingCharacters(in: .whitespacesAndNewlines)
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .joined()
        
        guard !cleanedWord.isEmpty,
              let encodedWord = cleanedWord.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
              let url = URL(string: "\(Constants.dictionaryAPIBaseURL)\(encodedWord)") else {
            throw URLError(.badURL)
        }
        
        let (data, response) = try await session.data(for: url)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            throw URLError(.badServerResponse)
        }
        
        if httpResponse.statusCode == 404 {
            // Word not found in dictionary
            return WordDetails(
                word: word,
                phonetic: "/\(word)/",
                audioURL: nil,
                definitions: ["Definition not found. You can still practice this word or add it to your basket."]
            )
        }
        
        guard (200...299).contains(httpResponse.statusCode) else {
            throw URLError(.badServerResponse)
        }
        
        let decoder = JSONDecoder()
        let entries = try decoder.decode([DictionaryEntry].self, from: data)
        
        guard let firstEntry = entries.first else {
            throw URLError(.cannotParseResponse)
        }
        
        // Find phonetic representation
        let phoneticText = firstEntry.phonetic ?? firstEntry.phonetics?.first(where: { $0.text != nil })?.text ?? "/\(firstEntry.word)/"
        
        // Find phonetic audio URL
        var audioURL: URL? = nil
        if let audioString = firstEntry.phonetics?.first(where: { !($0.audio ?? "").isEmpty })?.audio,
           let url = URL(string: audioString) {
            audioURL = url
        }
        
        // Format definitions
        var displayDefinitions: [String] = []
        if let meanings = firstEntry.meanings {
            for meaning in meanings {
                let part = meaning.partOfSpeech
                if let firstDef = meaning.definitions.first {
                    var defString = "[\(part)] \(firstDef.definition)"
                    if let ex = firstDef.example {
                        defString += " (e.g. \"\(ex)\")"
                    }
                    displayDefinitions.append(defString)
                }
            }
        }
        
        if displayDefinitions.isEmpty {
            displayDefinitions.append("Meaning details unavailable.")
        }
        
        return WordDetails(
            word: firstEntry.word,
            phonetic: phoneticText,
            audioURL: audioURL,
            definitions: displayDefinitions
        )
    }
}
