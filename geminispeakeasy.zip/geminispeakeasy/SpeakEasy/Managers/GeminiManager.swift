import Foundation

enum GeminiError: LocalizedError {
    case invalidURL
    case networkError(Error)
    case invalidResponse
    case apiError(String)
    case decodingError
    
    var errorDescription: String? {
        switch self {
        case .invalidURL: return "Invalid Gemini API endpoint URL."
        case .networkError(let error): return "Network failure: \(error.localizedDescription)"
        case .invalidResponse: return "Received invalid response from Google Gemini server."
        case .apiError(let message): return "Gemini API Error: \(message)"
        case .decodingError: return "Failed to decode the response from Gemini."
        }
    }
}

final class GeminiManager {
    static let shared = GeminiManager()
    
    private let session = URLSession.shared
    
    private init() {}
    
    /// Generates content using the Gemini 1.5 Flash model.
    func generateContent(prompt: String, forceJson: Bool = false) async throws -> String {
        let key = Config.geminiAPIKey
        let model = Constants.geminiModel
        
        let urlString = "\(Constants.geminiAPIBaseURL)\(model):generateContent?key=\(key)"
        guard let url = URL(string: urlString) else {
            throw GeminiError.invalidURL
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Define payload
        var parts: [[String: Any]] = [["text": prompt]]
        var contents: [[String: Any]] = [["parts": parts]]
        var payload: [String: Any] = ["contents": contents]
        
        if forceJson {
            payload["generationConfig"] = [
                "responseMimeType": "application/json"
            ]
        }
        
        request.httpBody = try? JSONSerialization.data(withJSONObject: payload)
        
        let (data, response) = try await session.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            throw GeminiError.invalidResponse
        }
        
        if !(200...299).contains(httpResponse.statusCode) {
            if let errorJson = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let error = errorJson["error"] as? [String: Any],
               let message = error["message"] as? String {
                throw GeminiError.apiError(message)
            }
            throw GeminiError.apiError("HTTP status code \(httpResponse.statusCode)")
        }
        
        // Parse Gemini response JSON structure:
        // candidates -> safetyRatings, content -> parts -> text
        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let candidates = json["candidates"] as? [[String: Any]],
              let firstCandidate = candidates.first,
              let content = firstCandidate["content"] as? [String: Any],
              let partsArray = content["parts"] as? [[String: Any]],
              let firstPart = partsArray.first,
              let text = firstPart["text"] as? String else {
            throw GeminiError.decodingError
        }
        
        return text.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    // MARK: - Specialized AI Operations
    
    func summarize(text: String) async throws -> String {
        let prompt = """
        You are an English teacher. Summarize the following reading passage in a clear, concise way using simple bullet points. Keep the language natural yet accessible (around B1 intermediate level).
        
        Passage:
        "\(text)"
        """
        return try await generateContent(prompt: prompt)
    }
    
    func simplify(text: String) async throws -> String {
        let prompt = """
        You are an expert ESL (English as a Second Language) content editor. Rewrite the following text to simplify the vocabulary and structure. Use shorter sentences, easier words, and active voice. Keep the core message exactly the same, but target a beginner to lower-intermediate English level.
        
        Original Text:
        "\(text)"
        """
        return try await generateContent(prompt: prompt)
    }
    
    func explainGrammar(text: String) async throws -> String {
        let prompt = """
        You are an English language expert. Analyze the grammar, idioms, and sentence structures of the following passage. List 3-4 key grammar patterns or interesting vocabulary usages found in the text. For each, give a clear explanation, state its usage rule, and provide an illustrative example. Format with clean spacing and clear headings.
        
        Passage:
        "\(text)"
        """
        return try await generateContent(prompt: prompt)
    }
    
    func generateQuiz(text: String) async throws -> [QuizQuestion] {
        let prompt = """
        You are a reading comprehension evaluator. Create a 3-question reading quiz based on the text below.
        Return ONLY a JSON array containing exactly 3 objects. Do not write markdown, code blocks, or explanations. Just pure JSON.
        Each object must have these exact keys:
        - "question": A string for the comprehension question.
        - "options": An array of exactly 4 strings containing candidate answers.
        - "correctIndex": An integer from 0 to 3 pointing to the correct answer in the options array.
        
        Text:
        "\(text)"
        """
        
        let jsonResponse = try await generateContent(prompt: prompt, forceJson: true)
        
        guard let jsonData = jsonResponse.data(using: .utf8) else {
            throw GeminiError.decodingError
        }
        
        let decoder = JSONDecoder()
        do {
            return try decoder.decode([QuizQuestion].self, from: jsonData)
        } catch {
            print("Failed to decode Gemini quiz json: \(error)")
            print("Raw JSON response was: \(jsonResponse)")
            throw GeminiError.decodingError
        }
    }
}

// MARK: - Quiz Model Struct
struct QuizQuestion: Codable, Identifiable {
    var id: UUID { UUID() }
    let question: String
    let options: [String]
    let correctIndex: Int
    
    enum CodingKeys: String, CodingKey {
        case question
        case options
        case correctIndex
    }
}
