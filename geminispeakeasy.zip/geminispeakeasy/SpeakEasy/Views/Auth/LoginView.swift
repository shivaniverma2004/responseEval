import SwiftUI

struct LoginView: View {
    @EnvironmentObject var viewModel: AuthViewModel
    @State private var showingSignUp = false
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        NavigationView {
            ZStack {
                // Background subtle gradient
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color.adaptiveColor(light: Color(red: 0.95, green: 0.96, blue: 0.99), dark: Color(red: 0.04, green: 0.05, blue: 0.08), scheme: colorScheme),
                        Color.adaptiveColor(light: Color(red: 0.90, green: 0.92, blue: 0.97), dark: Color(red: 0.07, green: 0.08, blue: 0.12), scheme: colorScheme)
                    ]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 32) {
                        Spacer().frame(height: 40)
                        
                        // Logo / Header
                        VStack(spacing: 12) {
                            ZStack {
                                Circle()
                                    .fill(LinearGradient(
                                        colors: [Constants.Colors.primaryGradientStart, Constants.Colors.primaryGradientEnd],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    ))
                                    .frame(width: 80, height: 80)
                                    .shadow(color: Constants.Colors.primaryGradientStart.opacity(0.4), radius: 12, x: 0, y: 6)
                                
                                Image(systemName: "bubble.left.and.bubble.right.fill")
                                    .font(.system(size: 36, weight: .bold))
                                    .foregroundColor(.white)
                            }
                            
                            Text("SpeakEasy")
                                .font(.system(size: 32, weight: .bold, design: .rounded))
                                .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                            
                            Text("Speak, write and understand English with absolute confidence.")
                                .font(.subheadline)
                                .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textSecondaryLight, dark: Constants.Colors.textSecondaryDark, scheme: colorScheme))
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 32)
                        }
                        
                        // Input Card Container
                        VStack(spacing: 20) {
                            if let error = viewModel.errorMessage {
                                Text(error)
                                    .font(.footnote)
                                    .fontWeight(.semibold)
                                    .foregroundColor(.white)
                                    .padding(.vertical, 12)
                                    .padding(.horizontal)
                                    .frame(maxWidth: .infinity)
                                    .background(Constants.Colors.danger)
                                    .cornerRadius(12)
                                    .transition(.opacity.combined(with: .scale))
                            }
                            
                            // Email Field
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Email Address")
                                    .font(.footnote)
                                    .fontWeight(.bold)
                                    .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textSecondaryLight, dark: Constants.Colors.textSecondaryDark, scheme: colorScheme))
                                
                                HStack {
                                    Image(systemName: "envelope.fill")
                                        .foregroundColor(Constants.Colors.primaryGradientStart)
                                    TextField("name@example.com", text: $viewModel.email)
                                        .keyboardType(.emailAddress)
                                        .autocapitalization(.none)
                                        .disableAutocorrection(true)
                                }
                                .padding()
                                .background(Color.adaptiveColor(light: Color.black.opacity(0.03), dark: Color.white.opacity(0.04), scheme: colorScheme))
                                .cornerRadius(12)
                            }
                            
                            // Password Field
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Password")
                                    .font(.footnote)
                                    .fontWeight(.bold)
                                    .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textSecondaryLight, dark: Constants.Colors.textSecondaryDark, scheme: colorScheme))
                                
                                HStack {
                                    Image(systemName: "lock.fill")
                                        .foregroundColor(Constants.Colors.primaryGradientStart)
                                    SecureField("••••••••", text: $viewModel.password)
                                }
                                .padding()
                                .background(Color.adaptiveColor(light: Color.black.opacity(0.03), dark: Color.white.opacity(0.04), scheme: colorScheme))
                                .cornerRadius(12)
                            }
                            
                            // Sign In Button
                            Button(action: {
                                HapticManager.shared.triggerMedium()
                                Task {
                                    await viewModel.login()
                                }
                            }) {
                                HStack {
                                    if viewModel.isLoading {
                                        ProgressView()
                                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                    } else {
                                        Text("Log In")
                                            .fontWeight(.bold)
                                        Image(systemName: "arrow.right")
                                    }
                                }
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(LinearGradient(
                                    colors: [Constants.Colors.primaryGradientStart, Constants.Colors.primaryGradientEnd],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                ))
                                .cornerRadius(12)
                                .shadow(color: Constants.Colors.primaryGradientStart.opacity(0.3), radius: 8, x: 0, y: 4)
                            }
                            .disabled(viewModel.isLoading)
                        }
                        .padding(24)
                        .background(Color.adaptiveColor(
                            light: Constants.Colors.cardBackgroundLight,
                            dark: Constants.Colors.cardBackgroundDark,
                            scheme: colorScheme
                        ))
                        .cornerRadius(16)
                        .shadow(color: Color.black.opacity(0.05), radius: 15, x: 0, y: 10)
                        .padding(.horizontal, 20)
                        
                        // Bottom Actions
                        VStack(spacing: 16) {
                            Button(action: {
                                HapticManager.shared.triggerLight()
                                viewModel.continueAsGuest()
                            }) {
                                Text("Continue as Guest")
                                    .fontWeight(.bold)
                                    .foregroundColor(Constants.Colors.primaryGradientStart)
                            }
                            
                            HStack {
                                Text("Don't have an account?")
                                    .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textSecondaryLight, dark: Constants.Colors.textSecondaryDark, scheme: colorScheme))
                                
                                Button(action: {
                                    HapticManager.shared.triggerLight()
                                    showingSignUp = true
                                }) {
                                    Text("Sign Up")
                                        .fontWeight(.bold)
                                        .foregroundColor(Constants.Colors.primaryGradientEnd)
                                }
                            }
                            .font(.footnote)
                        }
                        
                        Spacer()
                    }
                }
            }
            .navigationBarHidden(true)
            .background(
                NavigationLink(
                    destination: SignupView().environmentObject(viewModel),
                    isActive: $showingSignUp,
                    label: { EmptyView() }
                )
            )
        }
    }
}
