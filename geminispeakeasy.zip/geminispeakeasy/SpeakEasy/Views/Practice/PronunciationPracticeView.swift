import SwiftUI

struct PronunciationPracticeView: View {
    let word: String
    
    @StateObject private var viewModel: PracticeViewModel
    @Environment(\.presentationMode) private var presentationMode
    @Environment(\.colorScheme) var colorScheme
    
    init(word: String) {
        self.word = word
        _viewModel = StateObject(wrappedValue: PracticeViewModel(word: word))
    }
    
    var body: some View {
        ZStack {
            Color.adaptiveColor(light: Constants.Colors.backgroundLight, dark: Constants.Colors.backgroundDark, scheme: colorScheme)
                .ignoresSafeArea()
            
            VStack(spacing: 32) {
                // Top header controls
                HStack {
                    Button(action: {
                        HapticManager.shared.triggerLight()
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        Image(systemName: "xmark")
                            .font(.headline)
                            .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                            .padding(10)
                            .background(Color.adaptiveColor(light: Color.white, dark: Color.white.opacity(0.06), scheme: colorScheme))
                            .clipShape(Circle())
                    }
                    Spacer()
                    Text("Pronunciation Practice")
                        .font(.headline)
                    Spacer()
                    // Dummy space to center title
                    Spacer().frame(width: 40)
                }
                .padding(.horizontal)
                .padding(.top, 10)
                
                // Target Word card
                VStack(spacing: 8) {
                    Text("TARGET WORD")
                        .font(.caption)
                        .fontWeight(.bold)
                        .foregroundColor(.gray)
                    
                    Text(word.capitalized)
                        .font(.system(size: 38, weight: .bold, design: .rounded))
                        .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                    
                    Button(action: {
                        HapticManager.shared.triggerLight()
                        viewModel.playModelPronunciation()
                    }) {
                        Label("Listen to Model", systemImage: "speaker.wave.2.fill")
                            .font(.footnote)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .padding(.vertical, 6)
                            .padding(.horizontal, 16)
                            .background(Constants.Colors.primaryGradientStart)
                            .clipShape(Capsule())
                    }
                }
                .padding(.vertical, 20)
                .frame(maxWidth: .infinity)
                .premiumCard(scheme: colorScheme)
                .padding(.horizontal)
                
                // Circular Score and Mic Meter
                VStack(spacing: 16) {
                    ZStack {
                        // Outer Ring Background
                        Circle()
                            .stroke(Color.gray.opacity(0.12), lineWidth: 16)
                            .frame(width: 180, height: 180)
                        
                        if let score = viewModel.score {
                            // Animated Score Ring
                            Circle()
                                .trim(from: 0.0, to: CGFloat(score / 100.0))
                                .stroke(
                                    score >= 90.0 ? Constants.Colors.success : (score >= 50.0 ? Constants.Colors.warning : Constants.Colors.danger),
                                    style: StrokeStyle(lineWidth: 16, lineCap: .round)
                                )
                                .frame(width: 180, height: 180)
                                .rotationEffect(Angle(degrees: -90))
                                .animation(.easeOut(duration: 0.8), value: score)
                            
                            VStack(spacing: 4) {
                                Text("\(Int(score))%")
                                    .font(.system(size: 40, weight: .bold, design: .rounded))
                                    .foregroundColor(score >= 90.0 ? Constants.Colors.success : (score >= 50.0 ? Constants.Colors.warning : Constants.Colors.danger))
                                Text("Score")
                                    .font(.caption)
                                    .foregroundColor(.gray)
                                    .fontWeight(.bold)
                            }
                        } else {
                            // Idle/Recording Animation Ring
                            Circle()
                                .stroke(
                                    viewModel.isRecording ? Constants.Colors.accentSecondary : Constants.Colors.primaryGradientStart.opacity(0.3),
                                    style: StrokeStyle(lineWidth: 16, lineCap: .round)
                                )
                                .frame(width: 180, height: 180)
                                .scaleEffect(viewModel.isRecording ? 1.05 : 1.0)
                                .animation(.easeInOut(duration: 0.65).repeatForever(autoreverses: true), value: viewModel.isRecording)
                            
                            Image(systemName: viewModel.isRecording ? "waveform.and.mic" : "mic.fill")
                                .font(.system(size: 48))
                                .foregroundColor(viewModel.isRecording ? Constants.Colors.accentSecondary : Constants.Colors.primaryGradientStart)
                        }
                    }
                    
                    if let message = viewModel.errorMessage {
                        Text(message)
                            .font(.footnote)
                            .foregroundColor(Constants.Colors.danger)
                            .fontWeight(.semibold)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                    } else if !viewModel.feedbackMessage.isEmpty {
                        Text(viewModel.feedbackMessage)
                            .font(.subheadline)
                            .fontWeight(.bold)
                            .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                    }
                }
                
                // Live Transcription Box
                VStack(alignment: .leading, spacing: 8) {
                    Text("YOU SPONTANEOUSLY SAID:")
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundColor(.gray)
                    
                    Text(viewModel.transcription.isEmpty ? (viewModel.isRecording ? "Listening..." : "Press record and speak clear English.") : viewModel.transcription)
                        .font(.body)
                        .italic(viewModel.transcription.isEmpty)
                        .foregroundColor(viewModel.transcription.isEmpty ? .gray : Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                        .frame(maxWidth: .infinity, minHeight: 60, alignment: .leading)
                }
                .padding()
                .background(Color.adaptiveColor(light: Color.black.opacity(0.02), dark: Color.white.opacity(0.04), scheme: colorScheme))
                .cornerRadius(12)
                .padding(.horizontal)
                
                Spacer()
                
                // Core action button
                VStack(spacing: 12) {
                    Button(action: {
                        Task {
                            await viewModel.toggleRecording()
                        }
                    }) {
                        HStack {
                            Image(systemName: viewModel.isRecording ? "stop.fill" : "mic.fill")
                            Text(viewModel.isRecording ? "Tap to Finish" : "Start Recording")
                                .fontWeight(.bold)
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(
                            LinearGradient(
                                colors: viewModel.isRecording ? [Constants.Colors.danger, Constants.Colors.danger.opacity(0.85)] : [Constants.Colors.primaryGradientStart, Constants.Colors.primaryGradientEnd],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .cornerRadius(12)
                        .shadow(color: (viewModel.isRecording ? Constants.Colors.danger : Constants.Colors.primaryGradientStart).opacity(0.35), radius: 8, x: 0, y: 4)
                    }
                    
                    if viewModel.score != nil {
                        Button(action: {
                            HapticManager.shared.triggerLight()
                            Task {
                                await viewModel.startRecording()
                            }
                        }) {
                            Text("Try Again")
                                .fontWeight(.bold)
                                .foregroundColor(Constants.Colors.primaryGradientStart)
                        }
                    }
                }
                .padding()
            }
        }
        .onDisappear {
            // Stop recording safely when exiting view
            if viewModel.isRecording {
                viewModel.stopRecordingAndEvaluate()
            }
        }
    }
}
