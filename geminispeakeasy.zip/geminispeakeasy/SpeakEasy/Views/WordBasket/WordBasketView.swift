import SwiftUI

struct WordBasketView: View {
    @StateObject private var viewModel = WordBasketViewModel()
    @Environment(\.colorScheme) var colorScheme
    
    @State private var selectedWordToDetail: CDWord? = nil
    @State private var showingPracticeSheet = false
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.adaptiveColor(light: Constants.Colors.backgroundLight, dark: Constants.Colors.backgroundDark, scheme: colorScheme)
                    .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // Sorting and Filter bar
                    VStack(spacing: 12) {
                        // Filters segment
                        HStack {
                            Text("Difficulty:")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(.gray)
                            
                            Picker("Difficulty Filter", selection: $viewModel.difficultyFilter) {
                                Text("All").tag("All")
                                Text("Easy").tag("Easy")
                                Text("Medium").tag("Medium")
                                Text("Hard").tag("Hard")
                            }
                            .pickerStyle(SegmentedPickerStyle())
                            .onChange(of: viewModel.difficultyFilter) { _ in
                                viewModel.fetchWords()
                            }
                        }
                        
                        // Sorting options
                        HStack {
                            Text("Sort by:")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(.gray)
                            
                            Picker("Sort Option", selection: $viewModel.sortOption) {
                                Text("Newest").tag("Newest")
                                Text("A-Z").tag("Alphabetical")
                                Text("Score").tag("Score")
                            }
                            .pickerStyle(SegmentedPickerStyle())
                            .onChange(of: viewModel.sortOption) { _ in
                                viewModel.fetchWords()
                            }
                        }
                    }
                    .padding()
                    .background(Color.adaptiveColor(light: Color.white, dark: Constants.Colors.cardBackgroundDark, scheme: colorScheme))
                    .shadow(color: Color.black.opacity(0.02), radius: 5, x: 0, y: 2)
                    
                    if viewModel.words.isEmpty {
                        Spacer()
                        VStack(spacing: 12) {
                            Image(systemName: "archivebox.fill")
                                .font(.system(size: 60))
                                .foregroundColor(Constants.Colors.primaryGradientStart.opacity(0.4))
                            Text("Word Basket Empty")
                                .font(.headline)
                                .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                            Text("Save words from scanned readings to view definitions and practice pronunciation later.")
                                .font(.subheadline)
                                .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textSecondaryLight, dark: Constants.Colors.textSecondaryDark, scheme: colorScheme))
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 40)
                        }
                        Spacer()
                    } else {
                        List {
                            ForEach(viewModel.words, id: \.id) { word in
                                Button(action: {
                                    HapticManager.shared.triggerLight()
                                    selectedWordToDetail = word
                                }) {
                                    HStack {
                                        VStack(alignment: .leading, spacing: 6) {
                                            HStack(spacing: 8) {
                                                Text(word.text ?? "")
                                                    .font(.headline)
                                                    .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                                                
                                                // Difficulty tag
                                                let diff = word.difficulty ?? "Medium"
                                                Text(diff)
                                                    .font(.system(size: 9, weight: .bold))
                                                    .foregroundColor(.white)
                                                    .padding(.horizontal, 6)
                                                    .padding(.vertical, 2)
                                                    .background(diff == "Hard" ? Constants.Colors.danger : (diff == "Easy" ? Constants.Colors.success : Constants.Colors.primaryGradientStart))
                                                    .cornerRadius(4)
                                            }
                                            
                                            if let meaning = word.meaning {
                                                Text(meaning)
                                                    .font(.caption)
                                                    .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textSecondaryLight, dark: Constants.Colors.textSecondaryDark, scheme: colorScheme))
                                                    .lineLimit(2)
                                                    .multilineTextAlignment(.leading)
                                            }
                                        }
                                        
                                        Spacer()
                                        
                                        // Score Indicator
                                        let avgScore = word.averageScore
                                        if avgScore > 0 {
                                            VStack(alignment: .trailing, spacing: 4) {
                                                Text("\(Int(avgScore))%")
                                                    .font(.headline)
                                                    .fontWeight(.bold)
                                                    .foregroundColor(avgScore >= 80 ? Constants.Colors.success : (avgScore >= 50 ? Constants.Colors.warning : Constants.Colors.danger))
                                                Text("Avg Score")
                                                    .font(.system(size: 8))
                                                    .foregroundColor(.gray)
                                            }
                                        } else {
                                            Image(systemName: "chevron.right")
                                                .foregroundColor(.gray.opacity(0.5))
                                        }
                                    }
                                    .padding(.vertical, 4)
                                }
                                .contextMenu {
                                    // Change difficulty options
                                    Menu("Change Difficulty") {
                                        Button("Easy") {
                                            viewModel.updateWordDifficulty(word, to: "Easy")
                                        }
                                        Button("Medium") {
                                            viewModel.updateWordDifficulty(word, to: "Medium")
                                        }
                                        Button("Hard") {
                                            viewModel.updateWordDifficulty(word, to: "Hard")
                                        }
                                    }
                                    
                                    Button(role: .destructive, action: {
                                        HapticManager.shared.triggerNotification(type: .warning)
                                        viewModel.deleteWord(word)
                                    }) {
                                        Label("Remove", systemImage: "trash")
                                    }
                                }
                            }
                            .onDelete { indexSet in
                                // Support swipe deletion
                                HapticManager.shared.triggerNotification(type: .warning)
                                for index in indexSet {
                                    let word = viewModel.words[index]
                                    viewModel.deleteWord(word)
                                }
                            }
                        }
                        .listStyle(PlainListStyle())
                    }
                }
            }
            .navigationTitle("Saved Word Basket")
            .sheet(item: $selectedWordToDetail) { word in
                // Detailed word info modal
                VStack(spacing: 24) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(word.text?.capitalized ?? "")
                                .font(.title)
                                .fontWeight(.bold)
                            Text("Difficulty Level: \(word.difficulty ?? "Medium")")
                                .font(.caption)
                                .foregroundColor(.gray)
                                .fontWeight(.semibold)
                        }
                        
                        Spacer()
                        
                        Button(action: {
                            HapticManager.shared.triggerLight()
                            SpeechManager.shared.speak(text: word.text ?? "", rate: 0.7)
                        }) {
                            Image(systemName: "speaker.wave.2.bubble.left.fill")
                                .font(.title3)
                                .foregroundColor(.white)
                                .padding(10)
                                .background(Constants.Colors.primaryGradientStart)
                                .clipShape(Circle())
                        }
                    }
                    
                    if let meaning = word.meaning {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("DICTIONARY MEANING")
                                .font(.caption2)
                                .fontWeight(.bold)
                                .foregroundColor(.gray)
                            
                            ScrollView {
                                Text(meaning)
                                    .font(.subheadline)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            .frame(maxHeight: 120)
                        }
                        .padding()
                        .background(Color.black.opacity(0.02))
                        .cornerRadius(10)
                    }
                    
                    // Practice history scores list
                    let scores = word.scoresArray
                    if !scores.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("PRONUNCIATION HISTORY")
                                .font(.caption2)
                                .fontWeight(.bold)
                                .foregroundColor(.gray)
                            
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 12) {
                                    ForEach(scores, id: \.id) { score in
                                        VStack(spacing: 4) {
                                            Text("\(Int(score.score))%")
                                                .font(.subheadline)
                                                .fontWeight(.bold)
                                                .foregroundColor(score.score >= 80 ? Constants.Colors.success : (score.score >= 50 ? Constants.Colors.warning : Constants.Colors.danger))
                                            
                                            // Date format
                                            let dateText = score.date != nil ? DateFormatter.localizedString(from: score.date!, dateStyle: .short, timeStyle: .none) : ""
                                            Text(dateText)
                                                .font(.system(size: 9))
                                                .foregroundColor(.gray)
                                        }
                                        .padding(8)
                                        .background(Color.white)
                                        .cornerRadius(8)
                                        .shadow(color: Color.black.opacity(0.04), radius: 3, x: 0, y: 1)
                                    }
                                }
                                .padding(.vertical, 4)
                            }
                        }
                    }
                    
                    Spacer()
                    
                    Button(action: {
                        HapticManager.shared.triggerMedium()
                        showingPracticeSheet = true
                    }) {
                        HStack {
                            Image(systemName: "waveform.and.mic")
                            Text("Practice Word")
                                .fontWeight(.bold)
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(LinearGradient(
                            colors: [Constants.Colors.primaryGradientStart, Constants.Colors.primaryGradientEnd],
                            startPoint: .leading,
                            endPoint: .trailing
                        ))
                        .cornerRadius(12)
                    }
                }
                .padding(24)
                .presentationDetents([.medium, .large])
                .sheet(isPresented: $showingPracticeSheet) {
                    PronunciationPracticeView(word: word.text ?? "")
                }
            }
            .onAppear {
                viewModel.fetchWords()
            }
        }
    }
}
