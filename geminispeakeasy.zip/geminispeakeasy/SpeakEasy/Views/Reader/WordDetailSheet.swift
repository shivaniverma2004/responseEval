import SwiftUI

struct WordDetailSheet: View {
    @ObservedObject var viewModel: ReaderViewModel
    @Environment(\.presentationMode) private var presentationMode
    @Environment(\.colorScheme) var colorScheme
    
    @State private var showingPractice = false
    @State private var selectedDifficulty = "Medium"
    
    var body: some View {
        ZStack {
            Color.adaptiveColor(light: Constants.Colors.backgroundLight, dark: Constants.Colors.backgroundDark, scheme: colorScheme)
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Header details
                if viewModel.isLookingUpWord {
                    Spacer()
                    ProgressView("Searching Dictionary...")
                    Spacer()
                } else if let details = viewModel.selectedWordDetails {
                    VStack(alignment: .leading, spacing: 16) {
                        // Title Word + Phonetic
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(details.word.capitalized)
                                    .font(.title2)
                                    .fontWeight(.bold)
                                    .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                                
                                Text(details.phonetic)
                                    .font(.subheadline)
                                    .foregroundColor(Constants.Colors.primaryGradientStart)
                                    .italic()
                            }
                            
                            Spacer()
                            
                            // Speak Audio
                            Button(action: {
                                viewModel.playSelectedWordAudio()
                            }) {
                                Image(systemName: "speaker.wave.2.bubble.left.fill")
                                    .font(.title2)
                                    .foregroundColor(.white)
                                    .padding(10)
                                    .background(Constants.Colors.primaryGradientStart)
                                    .clipShape(Circle())
                            }
                        }
                        
                        // Action: Add to Basket with Difficulty select
                        HStack {
                            Picker("Difficulty", selection: $selectedDifficulty) {
                                Text("Easy").tag("Easy")
                                Text("Medium").tag("Medium")
                                Text("Hard").tag("Hard")
                            }
                            .pickerStyle(SegmentedPickerStyle())
                            .frame(width: 200)
                            
                            Spacer()
                            
                            Button(action: {
                                viewModel.addSelectedWordToBasket(difficulty: selectedDifficulty)
                            }) {
                                Label("Save", systemImage: "bookmark.fill")
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding(.vertical, 8)
                                    .padding(.horizontal, 16)
                                    .background(Constants.Colors.primaryGradientEnd)
                                    .cornerRadius(8)
                            }
                        }
                        
                        Divider()
                        
                        // Definitions Scroll List
                        ScrollView {
                            VStack(alignment: .leading, spacing: 10) {
                                Text("Definitions")
                                    .font(.caption)
                                    .fontWeight(.bold)
                                    .foregroundColor(.gray)
                                
                                ForEach(details.definitions, id: \.self) { definition in
                                    Text(definition)
                                        .font(.subheadline)
                                        .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                                        .padding(.vertical, 4)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                }
                            }
                        }
                        
                        Spacer()
                        
                        // Practice pronunciation trigger
                        Button(action: {
                            HapticManager.shared.triggerMedium()
                            showingPractice = true
                        }) {
                            HStack {
                                Image(systemName: "waveform.and.mic")
                                Text("Practice Pronunciation")
                                    .fontWeight(.bold)
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(LinearGradient(
                                colors: [Constants.Colors.primaryGradientStart, Constants.Colors.primaryGradientEnd],
                                startPoint: .leading,
                                endPoint: .trailing
                            ))
                            .cornerRadius(12)
                        }
                    }
                    .padding(24)
                } else {
                    Spacer()
                    Text("Could not fetch details. Please try again.")
                        .font(.headline)
                    Spacer()
                }
            }
        }
        .sheet(isPresented: $showingPractice) {
            if let word = viewModel.selectedWord {
                PronunciationPracticeView(word: word.cleanText)
            }
        }
    }
}
