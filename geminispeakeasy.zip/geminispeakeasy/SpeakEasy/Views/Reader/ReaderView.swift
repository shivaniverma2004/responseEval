import SwiftUI

struct ReaderView: View {
    @StateObject private var viewModel: ReaderViewModel
    @Environment(\.colorScheme) var colorScheme
    
    @State private var showingFormatSheet = false
    @State private var showingAISheet = false
    @State private var showingWordSheet = false
    
    init(text: String) {
        _viewModel = StateObject(wrappedValue: ReaderViewModel(text: text))
    }
    
    var body: some View {
        ZStack {
            // Theme Background
            viewModel.layoutConfig.theme.backgroundColor
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Interactive Scrollable Text Area
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        if #available(iOS 16.0, *) {
                            FlowLayout(spacing: viewModel.layoutConfig.letterSpacing + 6, lineSpacing: viewModel.layoutConfig.lineSpacing) {
                                ForEach(viewModel.words) { word in
                                    Text(word.rawText)
                                        .font(.system(size: viewModel.layoutConfig.fontSize, weight: .regular))
                                        .foregroundColor(viewModel.layoutConfig.theme.textColor)
                                        .padding(.horizontal, 2)
                                        .padding(.vertical, 4)
                                        .background(viewModel.selectedWord == word ? Constants.Colors.accentSecondary.opacity(0.35) : Color.clear)
                                        .cornerRadius(4)
                                        .onTapGesture {
                                            Task {
                                                await viewModel.selectWord(word)
                                                showingWordSheet = true
                                            }
                                        }
                                }
                            }
                        } else {
                            // Fallback for older iOS: Standard scrollable text
                            // Note: Word tapping falls back to select text
                            Text(viewModel.originalText)
                                .font(.system(size: viewModel.layoutConfig.fontSize))
                                .foregroundColor(viewModel.layoutConfig.theme.textColor)
                                .lineSpacing(viewModel.layoutConfig.lineSpacing)
                        }
                    }
                    .padding()
                }
                
                // Active AI Text Results Banner (if present)
                if let aiResult = viewModel.aiResultText {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Text(viewModel.aiResultTitle)
                                .font(.headline)
                                .foregroundColor(Constants.Colors.primaryGradientStart)
                            Spacer()
                            Button(action: {
                                HapticManager.shared.triggerLight()
                                viewModel.clearAIResult()
                            }) {
                                Image(systemName: "xmark.circle.fill")
                                    .foregroundColor(.gray)
                            }
                        }
                        
                        ScrollView {
                            Text(aiResult)
                                .font(.subheadline)
                                .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .frame(maxHeight: 180)
                    }
                    .padding()
                    .background(Color.adaptiveColor(light: Color.white, dark: Constants.Colors.cardBackgroundDark, scheme: colorScheme))
                    .cornerRadius(12)
                    .shadow(color: Color.black.opacity(0.1), radius: 8, x: 0, y: -4)
                    .transition(.move(edge: .bottom))
                }
                
                // Bottom Toolbar Controls
                HStack {
                    // Format
                    Button(action: {
                        HapticManager.shared.triggerLight()
                        showingFormatSheet = true
                    }) {
                        VStack(spacing: 4) {
                            Image(systemName: "textformat.size")
                                .font(.title3)
                            Text("Format")
                                .font(.caption2)
                        }
                        .foregroundColor(Constants.Colors.primaryGradientStart)
                        .frame(maxWidth: .infinity)
                    }
                    
                    // Listen / TTS Controller
                    Button(action: {
                        HapticManager.shared.triggerMedium()
                        viewModel.toggleReadAloud()
                    }) {
                        VStack(spacing: 4) {
                            Image(systemName: viewModel.isSpeaking ? (viewModel.isPaused ? "play.circle.fill" : "pause.circle.fill") : "play.circle.fill")
                                .font(.title2)
                                .foregroundColor(.white)
                            Text("Listen")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                        }
                        .frame(width: 80, height: 60)
                        .background(LinearGradient(
                            colors: [Constants.Colors.primaryGradientStart, Constants.Colors.primaryGradientEnd],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ))
                        .clipShape(Capsule())
                        .shadow(color: Constants.Colors.primaryGradientStart.opacity(0.3), radius: 6, x: 0, y: 3)
                    }
                    
                    // AI features
                    Button(action: {
                        HapticManager.shared.triggerLight()
                        showingAISheet = true
                    }) {
                        VStack(spacing: 4) {
                            Image(systemName: "sparkles")
                                .font(.title3)
                            Text("AI Tools")
                                .font(.caption2)
                        }
                        .foregroundColor(Constants.Colors.primaryGradientEnd)
                        .frame(maxWidth: .infinity)
                    }
                }
                .padding(.vertical, 12)
                .background(Color.adaptiveColor(light: Color.white, dark: Constants.Colors.cardBackgroundDark, scheme: colorScheme))
                .shadow(color: Color.black.opacity(0.04), radius: 5, x: 0, y: -2)
            }
        }
        .navigationTitle("SpeakEasy Reader")
        .navigationBarTitleDisplayMode(.inline)
        .onDisappear {
            viewModel.stopReadAloud()
        }
        .sheet(isPresented: $showingFormatSheet) {
            TextFormatSheet(layoutConfig: $viewModel.layoutConfig)
                .presentationDetents([.fraction(0.35)])
        }
        .sheet(isPresented: $showingAISheet) {
            AISettingsSheet(viewModel: viewModel)
                .presentationDetents([.medium, .large])
        }
        .sheet(isPresented: $showingWordSheet, onDismiss: {
            viewModel.selectedWord = nil
        }) {
            WordDetailSheet(viewModel: viewModel)
                .presentationDetents([.fraction(0.4)])
        }
    }
}
