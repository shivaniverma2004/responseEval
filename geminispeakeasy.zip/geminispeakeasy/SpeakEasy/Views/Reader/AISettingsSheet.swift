import SwiftUI

struct AISettingsSheet: View {
    @ObservedObject var viewModel: ReaderViewModel
    @Environment(\.presentationMode) private var presentationMode
    @Environment(\.colorScheme) var colorScheme
    
    // Quiz states
    @State private var currentQuestionIndex = 0
    @State private var selectedOptionIndex: Int? = nil
    @State private var answersChecked = false
    @State private var quizScore = 0
    
    var body: some View {
        ZStack {
            Color.adaptiveColor(light: Constants.Colors.backgroundLight, dark: Constants.Colors.backgroundDark, scheme: colorScheme)
                .ignoresSafeArea()
            
            VStack {
                Text("SpeakEasy AI Assistant")
                    .font(.headline)
                    .padding(.top)
                
                if viewModel.isProcessingAI {
                    Spacer()
                    VStack(spacing: 16) {
                        ProgressView()
                            .scaleEffect(1.3)
                            .progressViewStyle(CircularProgressViewStyle(tint: Constants.Colors.primaryGradientStart))
                        Text("Gemini is thinking...")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    Spacer()
                } else if !viewModel.quizQuestions.isEmpty {
                    // Quiz Interface Active
                    ScrollView {
                        VStack(spacing: 24) {
                            Text("Reading Comprehension Quiz")
                                .font(.title3)
                                .fontWeight(.bold)
                                .foregroundColor(Constants.Colors.primaryGradientStart)
                            
                            // Question Card
                            let currentQuestion = viewModel.quizQuestions[currentQuestionIndex]
                            VStack(alignment: .leading, spacing: 16) {
                                Text("Question \(currentQuestionIndex + 1) of 3")
                                    .font(.caption)
                                    .fontWeight(.bold)
                                    .foregroundColor(.gray)
                                
                                Text(currentQuestion.question)
                                    .font(.headline)
                                    .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                                
                                ForEach(0..<currentQuestion.options.count, id: \.self) { index in
                                    Button(action: {
                                        if !answersChecked {
                                            HapticManager.shared.triggerLight()
                                            selectedOptionIndex = index
                                        }
                                    }) {
                                        HStack {
                                            Text(currentQuestion.options[index])
                                                .font(.subheadline)
                                                .fontWeight(.medium)
                                                .multilineTextAlignment(.leading)
                                            Spacer()
                                            
                                            if answersChecked {
                                                if index == currentQuestion.correctIndex {
                                                    Image(systemName: "checkmark.circle.fill")
                                                        .foregroundColor(.green)
                                                } else if index == selectedOptionIndex {
                                                    Image(systemName: "xmark.circle.fill")
                                                        .foregroundColor(.red)
                                                }
                                            } else {
                                                Circle()
                                                    .stroke(selectedOptionIndex == index ? Constants.Colors.primaryGradientStart : Color.gray.opacity(0.5), lineWidth: 2)
                                                    .fill(selectedOptionIndex == index ? Constants.Colors.primaryGradientStart : Color.clear)
                                                    .frame(width: 20, height: 20)
                                            }
                                        }
                                        .padding()
                                        .background(
                                            RoundedRectangle(cornerRadius: 10)
                                                .fill(
                                                    answersChecked ?
                                                    (index == currentQuestion.correctIndex ? Color.green.opacity(0.12) : (index == selectedOptionIndex ? Color.red.opacity(0.12) : Color.black.opacity(0.02))) :
                                                    (selectedOptionIndex == index ? Constants.Colors.primaryGradientStart.opacity(0.08) : Color.black.opacity(0.02))
                                                )
                                        )
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 10)
                                                .stroke(
                                                    answersChecked ?
                                                    (index == currentQuestion.correctIndex ? Color.green : (index == selectedOptionIndex ? Color.red : Color.clear)) :
                                                    (selectedOptionIndex == index ? Constants.Colors.primaryGradientStart : Color.clear),
                                                    lineWidth: 1.5
                                                )
                                        )
                                    }
                                    .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                                }
                            }
                            .premiumCard(scheme: colorScheme)
                            
                            // Navigation / Action Buttons
                            if !answersChecked {
                                Button(action: {
                                    guard selectedOptionIndex != nil else { return }
                                    HapticManager.shared.triggerMedium()
                                    answersChecked = true
                                    if selectedOptionIndex == currentQuestion.correctIndex {
                                        quizScore += 1
                                    }
                                }) {
                                    Text("Submit Answer")
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(selectedOptionIndex != nil ? Constants.Colors.primaryGradientStart : Color.gray)
                                        .cornerRadius(12)
                                }
                                .disabled(selectedOptionIndex == nil)
                            } else {
                                Button(action: {
                                    HapticManager.shared.triggerMedium()
                                    if currentQuestionIndex < 2 {
                                        currentQuestionIndex += 1
                                        selectedOptionIndex = nil
                                        answersChecked = false
                                    } else {
                                        // Finalized quiz
                                        viewModel.aiResultTitle = "Quiz Complete!"
                                        viewModel.aiResultText = "You scored \(quizScore) out of 3. Excellent reading session!"
                                        presentationMode.wrappedValue.dismiss()
                                    }
                                }) {
                                    Text(currentQuestionIndex < 2 ? "Next Question" : "Finish Quiz")
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(Constants.Colors.success)
                                        .cornerRadius(12)
                                }
                            }
                        }
                        .padding()
                    }
                } else {
                    // Regular Options Grid
                    ScrollView {
                        VStack(spacing: 16) {
                            Text("Select an AI utility to process the reading text using Gemini 1.5 Flash.")
                                .font(.caption)
                                .foregroundColor(.gray)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)
                            
                            // Summarize
                            AIOptionCard(
                                title: "Summarize Text",
                                icon: "doc.text.magnifyingglass",
                                details: "Condense long readings into easy-to-digest bullet points.",
                                color: Constants.Colors.primaryGradientStart
                            ) {
                                Task {
                                    await viewModel.runAISummarize()
                                    presentationMode.wrappedValue.dismiss()
                                }
                            }
                            
                            // Simplify
                            AIOptionCard(
                                title: "Simplify English",
                                icon: "sparkles",
                                details: "Rewrite passages with simpler vocabulary and sentences.",
                                color: Constants.Colors.accentSecondary
                            ) {
                                Task {
                                    await viewModel.runAISimplify()
                                    presentationMode.wrappedValue.dismiss()
                                }
                            }
                            
                            // Grammar
                            AIOptionCard(
                                title: "Explain Grammar",
                                icon: "book.fill",
                                details: "Break down complex sentences, highlight structures, and review idioms.",
                                color: Constants.Colors.primaryGradientEnd
                            ) {
                                Task {
                                    await viewModel.runAIGrammar()
                                    presentationMode.wrappedValue.dismiss()
                                }
                            }
                            
                            // Quiz
                            AIOptionCard(
                                title: "Generate Quiz",
                                icon: "questionmark.circle.fill",
                                details: "Create a 3-question reading comprehension quiz based on details.",
                                color: Color.orange
                            ) {
                                Task {
                                    await viewModel.runAIGenerateQuiz()
                                }
                            }
                        }
                        .padding()
                    }
                }
            }
        }
    }
}

struct AIOptionCard: View {
    let title: String
    let icon: String
    let details: String
    let color: Color
    let action: () -> Void
    
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        Button(action: {
            HapticManager.shared.triggerLight()
            action()
        }) {
            HStack(spacing: 16) {
                ZStack {
                    Circle()
                        .fill(color.opacity(0.12))
                        .frame(width: 44, height: 44)
                    
                    Image(systemName: icon)
                        .foregroundColor(color)
                        .font(.title3)
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.headline)
                        .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                    Text(details)
                        .font(.caption)
                        .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textSecondaryLight, dark: Constants.Colors.textSecondaryDark, scheme: colorScheme))
                        .multilineTextAlignment(.leading)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundColor(.gray.opacity(0.6))
            }
            .padding()
            .background(Color.adaptiveColor(light: Color.white, dark: Constants.Colors.cardBackgroundDark, scheme: colorScheme))
            .cornerRadius(12)
            .shadow(color: Color.black.opacity(0.04), radius: 5, x: 0, y: 2)
        }
    }
}
