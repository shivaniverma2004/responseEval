import SwiftUI

struct TextFormatSheet: View {
    @Binding var layoutConfig: ReaderLayoutConfig
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Reader Display Options")
                .font(.headline)
                .padding(.top, 10)
            
            // Theme selection
            VStack(alignment: .leading, spacing: 8) {
                Text("Background Theme")
                    .font(.caption)
                    .fontWeight(.bold)
                    .foregroundColor(.gray)
                
                Picker("Theme", selection: $layoutConfig.theme) {
                    ForEach(ReaderThemePreset.allCases) { preset in
                        Text(preset.rawValue).tag(preset)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
            }
            
            // Font size slider
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text("Font Size")
                        .font(.caption)
                        .fontWeight(.bold)
                        .foregroundColor(.gray)
                    Spacer()
                    Text("\(Int(layoutConfig.fontSize))pt")
                        .font(.caption)
                        .fontWeight(.semibold)
                }
                
                Slider(value: $layoutConfig.fontSize, in: 14...36, step: 1)
                    .accentColor(Constants.Colors.primaryGradientStart)
            }
            
            // Spacing options
            HStack(spacing: 20) {
                // Letter spacing
                VStack(alignment: .leading, spacing: 6) {
                    Text("Letter Spacing")
                        .font(.caption)
                        .fontWeight(.bold)
                        .foregroundColor(.gray)
                    
                    Slider(value: $layoutConfig.letterSpacing, in: 0...4, step: 0.5)
                        .accentColor(Constants.Colors.primaryGradientStart)
                }
                
                // Line spacing
                VStack(alignment: .leading, spacing: 6) {
                    Text("Line Spacing")
                        .font(.caption)
                        .fontWeight(.bold)
                        .foregroundColor(.gray)
                    
                    Slider(value: $layoutConfig.lineSpacing, in: 4...12, step: 1)
                        .accentColor(Constants.Colors.primaryGradientStart)
                }
            }
            
            Spacer()
        }
        .padding(24)
        .background(Color.adaptiveColor(light: Color.white, dark: Constants.Colors.cardBackgroundDark, scheme: colorScheme))
    }
}
