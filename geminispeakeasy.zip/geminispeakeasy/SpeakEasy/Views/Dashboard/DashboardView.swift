import SwiftUI

struct DashboardView: View {
    @StateObject private var viewModel = DashboardViewModel()
    @StateObject private var projectViewModel = ProjectViewModel()
    
    @State private var showingImagePicker = false
    @State private var pickerSourceType: UIImagePickerController.SourceType = .photoLibrary
    @State private var pickedImages: [UIImage] = []
    
    @State private var navigateToReview = false
    @State private var isEditingGoal = false
    @State private var tempGoal = 15
    
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        NavigationView {
            ZStack {
                // Background
                Color.adaptiveColor(light: Constants.Colors.backgroundLight, dark: Constants.Colors.backgroundDark, scheme: colorScheme)
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 24) {
                        // Header Greeting & Streak
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(viewModel.timeOfDayGreeting)
                                    .font(.subheadline)
                                    .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textSecondaryLight, dark: Constants.Colors.textSecondaryDark, scheme: colorScheme))
                                Text(viewModel.userName)
                                    .font(.system(size: 26, weight: .bold, design: .rounded))
                                    .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                            }
                            
                            Spacer()
                            
                            // Streak pill
                            HStack(spacing: 6) {
                                Image(systemName: "flame.fill")
                                    .foregroundColor(.orange)
                                Text("\(viewModel.currentStreak) Days")
                                    .font(.footnote)
                                    .fontWeight(.bold)
                                    .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                            }
                            .padding(.vertical, 8)
                            .padding(.horizontal, 12)
                            .background(Color.adaptiveColor(light: Color.white, dark: Color.white.opacity(0.06), scheme: colorScheme))
                            .cornerRadius(20)
                            .shadow(color: Color.black.opacity(0.04), radius: 5, x: 0, y: 2)
                        }
                        .padding(.horizontal)
                        .padding(.top, 10)
                        
                        // Summary Gradient Card
                        VStack(spacing: 16) {
                            HStack {
                                VStack(alignment: .leading, spacing: 6) {
                                    Text("DAILY PROGRESS")
                                        .font(.caption)
                                        .fontWeight(.bold)
                                        .foregroundColor(.white.opacity(0.8))
                                    
                                    Button(action: {
                                        HapticManager.shared.triggerLight()
                                        tempGoal = viewModel.readingGoal
                                        isEditingGoal = true
                                    }) {
                                        HStack(spacing: 4) {
                                            Text("\(viewModel.readingGoal) Min Goal")
                                                .font(.title2)
                                                .fontWeight(.bold)
                                                .foregroundColor(.white)
                                            Image(systemName: "pencil")
                                                .font(.caption)
                                                .foregroundColor(.white.opacity(0.8))
                                        }
                                    }
                                }
                                Spacer()
                                Image(systemName: "book.closed.circle.fill")
                                    .font(.system(size: 40))
                                    .foregroundColor(.white.opacity(0.9))
                            }
                            
                            Divider()
                                .background(Color.white.opacity(0.3))
                            
                            HStack(spacing: 20) {
                                VStack(alignment: .leading) {
                                    Text("\(viewModel.projectCount)")
                                        .font(.title3)
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)
                                    Text("Projects")
                                        .font(.caption)
                                        .foregroundColor(.white.opacity(0.8))
                                }
                                
                                Spacer()
                                
                                VStack(alignment: .leading) {
                                    Text("\(viewModel.wordCount)")
                                        .font(.title3)
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)
                                    Text("Words Saved")
                                        .font(.caption)
                                        .foregroundColor(.white.opacity(0.8))
                                }
                                
                                Spacer()
                                
                                VStack(alignment: .leading) {
                                    Text("\(viewModel.currentStreak * 10)xp")
                                        .font(.title3)
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)
                                    Text("Points")
                                        .font(.caption)
                                        .foregroundColor(.white.opacity(0.8))
                                }
                            }
                        }
                        .padding(20)
                        .background(LinearGradient(
                            colors: [Constants.Colors.primaryGradientStart, Constants.Colors.primaryGradientEnd],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ))
                        .cornerRadius(Constants.Layout.cornerRadius)
                        .shadow(color: Constants.Colors.primaryGradientStart.opacity(0.35), radius: 10, x: 0, y: 6)
                        .padding(.horizontal)
                        
                        // Upload Actions Card
                        VStack(spacing: 12) {
                            Text("Import Text to Practice")
                                .font(.headline)
                                .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                                .frame(maxWidth: .infinity, alignment: .leading)
                            
                            HStack(spacing: 16) {
                                Button(action: {
                                    HapticManager.shared.triggerMedium()
                                    pickerSourceType = .camera
                                    showingImagePicker = true
                                }) {
                                    VStack(spacing: 8) {
                                        Image(systemName: "camera.fill")
                                            .font(.title2)
                                        Text("Camera Scan")
                                            .fontWeight(.semibold)
                                    }
                                    .foregroundColor(.white)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 16)
                                    .background(LinearGradient(
                                        colors: [Constants.Colors.primaryGradientStart, Constants.Colors.primaryGradientStart.opacity(0.85)],
                                        startPoint: .top,
                                        endPoint: .bottom
                                    ))
                                    .cornerRadius(12)
                                }
                                
                                Button(action: {
                                    HapticManager.shared.triggerMedium()
                                    pickerSourceType = .photoLibrary
                                    showingImagePicker = true
                                }) {
                                    VStack(spacing: 8) {
                                        Image(systemName: "photo.on.rectangle.angled")
                                            .font(.title2)
                                        Text("Photo Library")
                                            .fontWeight(.semibold)
                                    }
                                    .foregroundColor(Constants.Colors.primaryGradientStart)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 16)
                                    .background(Color.adaptiveColor(light: Constants.Colors.primaryGradientStart.opacity(0.08), dark: Color.white.opacity(0.06), scheme: colorScheme))
                                    .cornerRadius(12)
                                }
                            }
                        }
                        .premiumCard(scheme: colorScheme)
                        .padding(.horizontal)
                        
                        // Recent Projects Section
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                Text("Recent Reading Projects")
                                    .font(.headline)
                                    .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                                Spacer()
                            }
                            .padding(.horizontal)
                            
                            if viewModel.recentProjects.isEmpty {
                                Text("No recent projects. Scan or upload an image to begin learning.")
                                    .font(.subheadline)
                                    .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textSecondaryLight, dark: Constants.Colors.textSecondaryDark, scheme: colorScheme))
                                    .multilineTextAlignment(.center)
                                    .padding(.vertical, 20)
                                    .frame(maxWidth: .infinity)
                            } else {
                                ScrollView(.horizontal, showsIndicators: false) {
                                    HStack(spacing: 16) {
                                        ForEach(viewModel.recentProjects, id: \.id) { project in
                                            NavigationLink(destination: ProjectDetailView(project: project)) {
                                                VStack(alignment: .leading, spacing: 8) {
                                                    // Thumbnail
                                                    if let firstImage = project.imageArray.first,
                                                       let data = firstImage.imageData,
                                                       let uiImage = UIImage(data: data) {
                                                        Image(uiImage: uiImage)
                                                            .resizable()
                                                            .scaledToFill()
                                                            .frame(width: 140, height: 100)
                                                            .cornerRadius(10)
                                                            .clipped()
                                                    } else {
                                                        ZStack {
                                                            Color.adaptiveColor(light: Color.black.opacity(0.04), dark: Color.white.opacity(0.05), scheme: colorScheme)
                                                            Image(systemName: "doc.text.fill")
                                                                .font(.largeTitle)
                                                                .foregroundColor(Constants.Colors.primaryGradientStart)
                                                        }
                                                        .frame(width: 140, height: 100)
                                                        .cornerRadius(10)
                                                    }
                                                    
                                                    Text(project.name ?? "Unnamed Project")
                                                        .font(.subheadline)
                                                        .fontWeight(.bold)
                                                        .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                                                        .lineLimit(1)
                                                        .frame(width: 140, alignment: .leading)
                                                    
                                                    Text("\(project.imageArray.count) images")
                                                        .font(.caption)
                                                        .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textSecondaryLight, dark: Constants.Colors.textSecondaryDark, scheme: colorScheme))
                                                }
                                                .padding(10)
                                                .background(Color.adaptiveColor(light: Constants.Colors.cardBackgroundLight, dark: Constants.Colors.cardBackgroundDark, scheme: colorScheme))
                                                .cornerRadius(12)
                                                .shadow(color: Color.black.opacity(0.04), radius: 5, x: 0, y: 2)
                                            }
                                        }
                                    }
                                    .padding(.horizontal)
                                }
                            }
                        }
                        
                        // Recent Practiced Words Section
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Recent Practiced Words")
                                .font(.headline)
                                .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                                .padding(.horizontal)
                            
                            if viewModel.recentWords.isEmpty {
                                Text("No practiced words yet. Tapping on words inside the reader lets you practice.")
                                    .font(.subheadline)
                                    .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textSecondaryLight, dark: Constants.Colors.textSecondaryDark, scheme: colorScheme))
                                    .multilineTextAlignment(.center)
                                    .padding(.vertical, 20)
                                    .frame(maxWidth: .infinity)
                            } else {
                                ScrollView(.horizontal, showsIndicators: false) {
                                    HStack(spacing: 12) {
                                        ForEach(viewModel.recentWords, id: \.id) { word in
                                            VStack(alignment: .leading, spacing: 6) {
                                                HStack {
                                                    Text(word.text ?? "")
                                                        .font(.subheadline)
                                                        .fontWeight(.bold)
                                                        .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                                                    Spacer()
                                                    
                                                    // Score badge
                                                    let scoreVal = Int(word.averageScore)
                                                    Text("\(scoreVal)%")
                                                        .font(.caption)
                                                        .fontWeight(.bold)
                                                        .foregroundColor(scoreVal >= 80 ? Constants.Colors.success : (scoreVal >= 50 ? Constants.Colors.warning : Constants.Colors.danger))
                                                }
                                                
                                                Text(word.difficulty ?? "Medium")
                                                    .font(.caption2)
                                                    .fontWeight(.bold)
                                                    .foregroundColor(.white)
                                                    .padding(.horizontal, 6)
                                                    .padding(.vertical, 2)
                                                    .background(word.difficulty == "Hard" ? Constants.Colors.danger : (word.difficulty == "Easy" ? Constants.Colors.success : Constants.Colors.primaryGradientStart))
                                                    .cornerRadius(4)
                                                
                                                if let meaning = word.meaning {
                                                    Text(meaning)
                                                        .font(.caption)
                                                        .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textSecondaryLight, dark: Constants.Colors.textSecondaryDark, scheme: colorScheme))
                                                        .lineLimit(1)
                                                }
                                            }
                                            .padding(12)
                                            .frame(width: 160)
                                            .background(Color.adaptiveColor(light: Constants.Colors.cardBackgroundLight, dark: Constants.Colors.cardBackgroundDark, scheme: colorScheme))
                                            .cornerRadius(12)
                                            .shadow(color: Color.black.opacity(0.04), radius: 5, x: 0, y: 2)
                                        }
                                    }
                                    .padding(.horizontal)
                                }
                            }
                        }
                        
                        Spacer().frame(height: 20)
                    }
                }
                
                // Destination Review Redirect logic
                NavigationLink(
                    destination: ImageReviewView(images: pickedImages).environmentObject(projectViewModel),
                    isActive: $navigateToReview,
                    label: { EmptyView() }
                )
            }
            .navigationBarHidden(true)
            .sheet(isPresented: $showingImagePicker, onDismiss: {
                if !pickedImages.isEmpty {
                    // Staged picked images inside projectViewModel and navigate
                    projectViewModel.clearStaging()
                    projectViewModel.stageImages(pickedImages)
                    pickedImages.removeAll()
                    navigateToReview = true
                }
            }) {
                ImagePicker(sourceType: pickerSourceType, selectedImages: $pickedImages)
            }
            .sheet(isPresented: $isEditingGoal) {
                // Goal editing view sheet
                VStack(spacing: 24) {
                    Text("Adjust Daily Reading Goal")
                        .font(.headline)
                    
                    Stepper(value: $tempGoal, in: 5...120, step: 5) {
                        Text("\(tempGoal) minutes per day")
                            .fontWeight(.medium)
                    }
                    .padding()
                    .background(Color.black.opacity(0.02))
                    .cornerRadius(10)
                    
                    Button(action: {
                        HapticManager.shared.triggerMedium()
                        viewModel.updateReadingGoal(tempGoal)
                        isEditingGoal = false
                    }) {
                        Text("Save Goal")
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Constants.Colors.primaryGradientStart)
                            .cornerRadius(10)
                    }
                }
                .padding(24)
                .presentationDetents([.fraction(0.3)])
            }
            .onAppear {
                viewModel.loadSettings()
                viewModel.fetchDashboardData()
            }
        }
    }
}
