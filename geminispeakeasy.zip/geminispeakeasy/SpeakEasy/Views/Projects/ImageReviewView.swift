import SwiftUI

struct ImageReviewView: View {
    let images: [UIImage]
    
    @EnvironmentObject private var projectViewModel: ProjectViewModel
    @Environment(\.presentationMode) private var presentationMode
    @Environment(\.colorScheme) var colorScheme
    
    @State private var showingAddPicker = false
    @State private var pickedImages: [UIImage] = []
    
    @State private var showingSaveSheet = false
    @State private var isCreatingNew = true
    @State private var newProjectName = ""
    @State private var selectedProjectId: UUID? = nil
    
    @State private var extractedTextResult = ""
    @State private var navigateToReader = false
    
    private let columns = [
        GridItem(.adaptive(minimum: 100), spacing: 12)
    ]
    
    var body: some View {
        ZStack {
            Color.adaptiveColor(light: Constants.Colors.backgroundLight, dark: Constants.Colors.backgroundDark, scheme: colorScheme)
                .ignoresSafeArea()
            
            VStack {
                Text("Staged Images (\(projectViewModel.stagedImages.count))")
                    .font(.headline)
                    .padding(.top)
                
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 12) {
                        ForEach(0..<projectViewModel.stagedImages.count, id: \.self) { index in
                            ZStack(alignment: .topTrailing) {
                                Image(uiImage: projectViewModel.stagedImages[index])
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 100, height: 100)
                                    .cornerRadius(10)
                                    .clipped()
                                
                                Button(action: {
                                    HapticManager.shared.triggerLight()
                                    projectViewModel.removeStagedImage(at: index)
                                }) {
                                    Image(systemName: "xmark.circle.fill")
                                        .foregroundColor(Constants.Colors.danger)
                                        .background(Color.white.clipShape(Circle()))
                                        .font(.system(size: 20))
                                }
                                .padding(4)
                            }
                        }
                        
                        // Add More Grid Item
                        Button(action: {
                            HapticManager.shared.triggerLight()
                            showingAddPicker = true
                        }) {
                            VStack(spacing: 8) {
                                Image(systemName: "plus")
                                    .font(.title2)
                                Text("Add More")
                                    .font(.caption)
                                    .fontWeight(.bold)
                            }
                            .foregroundColor(Constants.Colors.primaryGradientStart)
                            .frame(width: 100, height: 100)
                            .background(Color.adaptiveColor(light: Constants.Colors.primaryGradientStart.opacity(0.08), dark: Color.white.opacity(0.05), scheme: colorScheme))
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Constants.Colors.primaryGradientStart, style: StrokeStyle(lineWidth: 1, dash: [4]))
                            )
                        }
                    }
                    .padding()
                }
                
                Spacer()
                
                // Bottom Actions
                VStack(spacing: 12) {
                    Button(action: {
                        HapticManager.shared.triggerMedium()
                        Task {
                            let text = await projectViewModel.processStagedOCRDirectly()
                            if !text.isEmpty {
                                self.extractedTextResult = text
                                self.navigateToReader = true
                            }
                        }
                    }) {
                        HStack {
                            Image(systemName: "book.fill")
                            Text("Read Now (No Saving)")
                                .fontWeight(.bold)
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Constants.Colors.primaryGradientStart)
                        .cornerRadius(12)
                        .shadow(color: Constants.Colors.primaryGradientStart.opacity(0.3), radius: 6, x: 0, y: 3)
                    }
                    .disabled(projectViewModel.stagedImages.isEmpty || projectViewModel.isLoading)
                    
                    Button(action: {
                        HapticManager.shared.triggerMedium()
                        showingSaveSheet = true
                    }) {
                        HStack {
                            Image(systemName: "folder.badge.plus")
                            Text("Save to Project & Read")
                                .fontWeight(.bold)
                        }
                        .foregroundColor(Constants.Colors.primaryGradientStart)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.adaptiveColor(light: Color.white, dark: Color.white.opacity(0.06), scheme: colorScheme))
                        .cornerRadius(12)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Constants.Colors.primaryGradientStart, lineWidth: 1.5)
                        )
                    }
                    .disabled(projectViewModel.stagedImages.isEmpty || projectViewModel.isLoading)
                }
                .padding()
            }
            
            // Loading Overlay
            if projectViewModel.isLoading {
                Color.black.opacity(0.5)
                    .ignoresSafeArea()
                
                VStack(spacing: 16) {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        .scaleEffect(1.5)
                    Text("Performing OCR...\nThis may take a moment.")
                        .font(.headline)
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                }
                .padding(32)
                .background(Color.black.opacity(0.8))
                .cornerRadius(16)
            }
            
            // Navigation link to Reader
            NavigationLink(
                destination: ReaderView(text: extractedTextResult),
                isActive: $navigateToReader,
                label: { EmptyView() }
            )
        }
        .sheet(isPresented: $showingAddPicker, onDismiss: {
            if !pickedImages.isEmpty {
                projectViewModel.stageImages(pickedImages)
                pickedImages.removeAll()
            }
        }) {
            ImagePicker(sourceType: .photoLibrary, selectedImages: $pickedImages)
        }
        .sheet(isPresented: $showingSaveSheet) {
            // Save settings sheet
            VStack(spacing: 24) {
                Text("Save Staged Images")
                    .font(.headline)
                
                Picker("Save Options", selection: $isCreatingNew) {
                    Text("New Project").tag(true)
                    Text("Existing Project").tag(false)
                }
                .pickerStyle(SegmentedPickerStyle())
                
                if isCreatingNew {
                    TextField("Project Name", text: $newProjectName)
                        .padding()
                        .background(Color.black.opacity(0.03))
                        .cornerRadius(10)
                } else {
                    if projectViewModel.projects.isEmpty {
                        Text("No existing projects found. Create a new one.")
                            .font(.caption)
                            .foregroundColor(.gray)
                    } else {
                        Picker("Select Project", selection: $selectedProjectId) {
                            ForEach(projectViewModel.projects, id: \.id) { proj in
                                Text(proj.name ?? "Unnamed").tag(proj.id)
                            }
                        }
                        .pickerStyle(WheelPickerStyle())
                        .frame(height: 100)
                    }
                }
                
                Button(action: {
                    HapticManager.shared.triggerMedium()
                    Task {
                        showingSaveSheet = false
                        if isCreatingNew {
                            let name = newProjectName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "New Scan" : newProjectName
                            let proj = await projectViewModel.saveStagedToProject(name: name)
                            // Combine text of project to read
                            self.extractedTextResult = proj.imageArray.compactMap { $0.extractedText }.joined(separator: "\n\n")
                            self.navigateToReader = true
                        } else if let selectedId = selectedProjectId,
                                  let proj = projectViewModel.projects.first(where: { $0.id == selectedId }) {
                            await projectViewModel.saveStagedToExistingProject(proj)
                            self.extractedTextResult = proj.imageArray.compactMap { $0.extractedText }.joined(separator: "\n\n")
                            self.navigateToReader = true
                        }
                    }
                }) {
                    Text("Save & Open Reader")
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Constants.Colors.primaryGradientStart)
                        .cornerRadius(10)
                }
                .disabled(!isCreatingNew && selectedProjectId == nil && !projectViewModel.projects.isEmpty)
            }
            .padding(24)
            .presentationDetents([.medium])
            .onAppear {
                // Initialize selected project if empty
                if selectedProjectId == nil {
                    selectedProjectId = projectViewModel.projects.first?.id
                }
            }
        }
        .onAppear {
            projectViewModel.fetchProjects()
        }
    }
}
