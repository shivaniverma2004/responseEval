import SwiftUI

struct ProjectDetailView: View {
    @ObservedObject var project: CDProject
    @StateObject private var viewModel = ProjectViewModel()
    
    @State private var showingAddPicker = false
    @State private var pickedImages: [UIImage] = []
    
    @State private var navigateToReader = false
    @State private var combinedTextResult = ""
    
    @Environment(\.presentationMode) private var presentationMode
    @Environment(\.colorScheme) var colorScheme
    
    private let columns = [
        GridItem(.flexible(), spacing: 12),
        GridItem(.flexible(), spacing: 12)
    ]
    
    var body: some View {
        ZStack {
            Color.adaptiveColor(light: Constants.Colors.backgroundLight, dark: Constants.Colors.backgroundDark, scheme: colorScheme)
                .ignoresSafeArea()
            
            VStack {
                if project.imageArray.isEmpty {
                    Spacer()
                    VStack(spacing: 16) {
                        Image(systemName: "photo.on.rectangle.angled")
                            .font(.system(size: 60))
                            .foregroundColor(Constants.Colors.primaryGradientStart.opacity(0.4))
                        Text("No Images in Project")
                            .font(.headline)
                        Text("Add images to start extracting text.")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    Spacer()
                } else {
                    ScrollView {
                        LazyVGrid(columns: columns, spacing: 16) {
                            ForEach(project.imageArray, id: \.id) { cdImage in
                                ZStack(alignment: .topTrailing) {
                                    if let data = cdImage.imageData,
                                       let uiImage = UIImage(data: data) {
                                        Image(uiImage: uiImage)
                                            .resizable()
                                            .scaledToFill()
                                            .frame(height: 140)
                                            .cornerRadius(12)
                                            .clipped()
                                    } else {
                                        Color.black.opacity(0.04)
                                            .frame(height: 140)
                                            .cornerRadius(12)
                                    }
                                    
                                    Button(action: {
                                        HapticManager.shared.triggerLight()
                                        viewModel.deleteImageFromProject(cdImage)
                                    }) {
                                        Image(systemName: "trash.circle.fill")
                                            .foregroundColor(.red)
                                            .background(Color.white.clipShape(Circle()))
                                            .font(.system(size: 24))
                                    }
                                    .padding(8)
                                }
                            }
                            
                            // Add Image Cell
                            Button(action: {
                                HapticManager.shared.triggerLight()
                                showingAddPicker = true
                            }) {
                                VStack(spacing: 10) {
                                    Image(systemName: "plus")
                                        .font(.title)
                                    Text("Add Image")
                                        .fontWeight(.semibold)
                                }
                                .foregroundColor(Constants.Colors.primaryGradientStart)
                                .frame(height: 140)
                                .frame(maxWidth: .infinity)
                                .background(Color.adaptiveColor(light: Constants.Colors.primaryGradientStart.opacity(0.08), dark: Color.white.opacity(0.05), scheme: colorScheme))
                                .cornerRadius(12)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(Constants.Colors.primaryGradientStart, style: StrokeStyle(lineWidth: 1, dash: [4]))
                                )
                            }
                        }
                        .padding()
                    }
                }
                
                Spacer()
                
                // Read Project Button
                Button(action: {
                    HapticManager.shared.triggerMedium()
                    let combinedText = project.imageArray
                        .compactMap { $0.extractedText }
                        .joined(separator: "\n\n")
                    
                    if !combinedText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                        self.combinedTextResult = combinedText
                        self.navigateToReader = true
                    }
                }) {
                    HStack {
                        Image(systemName: "book.fill")
                        Text("Open in Reader")
                            .fontWeight(.bold)
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Constants.Colors.primaryGradientStart)
                    .cornerRadius(12)
                    .shadow(color: Constants.Colors.primaryGradientStart.opacity(0.3), radius: 6, x: 0, y: 3)
                }
                .padding()
                .disabled(project.imageArray.isEmpty)
            }
            
            // Loading Overlay
            if viewModel.isLoading {
                Color.black.opacity(0.4)
                    .ignoresSafeArea()
                ProgressView("Analyzing Image & Running OCR...")
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.black.opacity(0.8))
                    .cornerRadius(12)
            }
            
            NavigationLink(
                destination: ReaderView(text: combinedTextResult),
                isActive: $navigateToReader,
                label: { EmptyView() }
            )
        }
        .navigationTitle(project.name ?? "Project Details")
        .sheet(isPresented: $showingAddPicker, onDismiss: {
            if !pickedImages.isEmpty {
                Task {
                    await viewModel.addImagesToProject(project: project, uiImages: pickedImages)
                    pickedImages.removeAll()
                }
            }
        }) {
            ImagePicker(sourceType: .photoLibrary, selectedImages: $pickedImages)
        }
    }
}
