import SwiftUI

struct ProjectsTabView: View {
    @StateObject private var viewModel = ProjectViewModel()
    @State private var searchText = ""
    @State private var showingCreateAlert = false
    @State private var newProjectName = ""
    
    @State private var selectedProjectToRename: CDProject? = nil
    @State private var renameText = ""
    
    @Environment(\.colorScheme) var colorScheme
    
    // Grid configuration
    private let columns = [
        GridItem(.flexible(), spacing: 16),
        GridItem(.flexible(), spacing: 16)
    ]
    
    var filteredProjects: [CDProject] {
        if searchText.isEmpty {
            return viewModel.projects
        } else {
            return viewModel.projects.filter { ($0.name ?? "").localizedCaseInsensitiveContains(searchText) }
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.adaptiveColor(light: Constants.Colors.backgroundLight, dark: Constants.Colors.backgroundDark, scheme: colorScheme)
                    .ignoresSafeArea()
                
                VStack {
                    // Search Bar
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(Constants.Colors.primaryGradientStart)
                        TextField("Search projects...", text: $searchText)
                            .disableAutocorrection(true)
                    }
                    .padding()
                    .background(Color.adaptiveColor(light: Color.white, dark: Color.white.opacity(0.06), scheme: colorScheme))
                    .cornerRadius(12)
                    .padding(.horizontal)
                    .padding(.top, 10)
                    
                    if filteredProjects.isEmpty {
                        Spacer()
                        VStack(spacing: 12) {
                            Image(systemName: "folder.badge.questionmark")
                                .font(.system(size: 60))
                                .foregroundColor(Constants.Colors.primaryGradientStart.opacity(0.5))
                            
                            Text("No Projects Found")
                                .font(.headline)
                                .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                            
                            Text("Create a new project or scan an image from the dashboard.")
                                .font(.subheadline)
                                .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textSecondaryLight, dark: Constants.Colors.textSecondaryDark, scheme: colorScheme))
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 40)
                        }
                        Spacer()
                    } else {
                        ScrollView {
                            LazyVGrid(columns: columns, spacing: 16) {
                                ForEach(filteredProjects, id: \.id) { project in
                                    NavigationLink(destination: ProjectDetailView(project: project)) {
                                        VStack(alignment: .leading, spacing: 10) {
                                            // Thumbnail View
                                            if let firstImage = project.imageArray.first,
                                               let data = firstImage.imageData,
                                               let uiImage = UIImage(data: data) {
                                                Image(uiImage: uiImage)
                                                    .resizable()
                                                    .scaledToFill()
                                                    .frame(height: 120)
                                                    .cornerRadius(8)
                                                    .clipped()
                                            } else {
                                                ZStack {
                                                    Color.black.opacity(0.04)
                                                    Image(systemName: "folder.fill")
                                                        .font(.system(size: 40))
                                                        .foregroundColor(Constants.Colors.primaryGradientStart)
                                                }
                                                .frame(height: 120)
                                                .cornerRadius(8)
                                            }
                                            
                                            VStack(alignment: .leading, spacing: 4) {
                                                Text(project.name ?? "Unnamed Project")
                                                    .font(.subheadline)
                                                    .fontWeight(.bold)
                                                    .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                                                    .lineLimit(1)
                                                
                                                Text("\(project.imageArray.count) images")
                                                    .font(.caption)
                                                    .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textSecondaryLight, dark: Constants.Colors.textSecondaryDark, scheme: colorScheme))
                                            }
                                        }
                                        .padding(10)
                                        .background(Color.adaptiveColor(light: Constants.Colors.cardBackgroundLight, dark: Constants.Colors.cardBackgroundDark, scheme: colorScheme))
                                        .cornerRadius(12)
                                        .shadow(color: Color.black.opacity(0.03), radius: 5, x: 0, y: 2)
                                        .contextMenu {
                                            Button(action: {
                                                HapticManager.shared.triggerLight()
                                                selectedProjectToRename = project
                                                renameText = project.name ?? ""
                                            }) {
                                                Label("Rename", systemImage: "pencil")
                                            }
                                            
                                            Button(role: .destructive, action: {
                                                HapticManager.shared.triggerNotification(type: .warning)
                                                viewModel.deleteProject(project)
                                            }) {
                                                Label("Delete", systemImage: "trash")
                                            }
                                        }
                                    }
                                }
                            }
                            .padding()
                        }
                    }
                }
            }
            .navigationTitle("My Projects")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        HapticManager.shared.triggerLight()
                        newProjectName = ""
                        showingCreateAlert = true
                    }) {
                        Image(systemName: "folder.badge.plus")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(Constants.Colors.primaryGradientStart)
                    }
                }
            }
            .sheet(isPresented: $showingCreateAlert) {
                VStack(spacing: 20) {
                    Text("New Project")
                        .font(.headline)
                    
                    TextField("Enter project name", text: $newProjectName)
                        .padding()
                        .background(Color.black.opacity(0.03))
                        .cornerRadius(10)
                    
                    Button(action: {
                        HapticManager.shared.triggerMedium()
                        if !newProjectName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                            _ = viewModel.createProject(name: newProjectName)
                        }
                        showingCreateAlert = false
                    }) {
                        Text("Create")
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Constants.Colors.primaryGradientStart)
                            .cornerRadius(10)
                    }
                }
                .padding(24)
                .presentationDetents([.fraction(0.28)])
            }
            .sheet(item: $selectedProjectToRename) { project in
                VStack(spacing: 20) {
                    Text("Rename Project")
                        .font(.headline)
                    
                    TextField("Enter new name", text: $renameText)
                        .padding()
                        .background(Color.black.opacity(0.03))
                        .cornerRadius(10)
                    
                    Button(action: {
                        HapticManager.shared.triggerMedium()
                        if !renameText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                            viewModel.renameProject(project, to: renameText)
                        }
                        selectedProjectToRename = nil
                    }) {
                        Text("Save")
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Constants.Colors.primaryGradientStart)
                            .cornerRadius(10)
                    }
                }
                .padding(24)
                .presentationDetents([.fraction(0.28)])
            }
            .onAppear {
                viewModel.fetchProjects()
            }
        }
    }
}
