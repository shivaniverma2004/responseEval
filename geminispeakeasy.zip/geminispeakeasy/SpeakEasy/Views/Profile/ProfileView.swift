import SwiftUI

struct ProfileView: View {
    @StateObject private var viewModel = ProfileViewModel()
    @EnvironmentObject private var authViewModel: AuthViewModel
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.adaptiveColor(light: Constants.Colors.backgroundLight, dark: Constants.Colors.backgroundDark, scheme: colorScheme)
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 24) {
                        // User Profile Header Card
                        VStack(spacing: 12) {
                            ZStack {
                                Circle()
                                    .fill(LinearGradient(
                                        colors: [Constants.Colors.primaryGradientStart, Constants.Colors.primaryGradientEnd],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    ))
                                    .frame(width: 80, height: 80)
                                
                                Text(viewModel.userName.prefix(1).uppercased())
                                    .font(.system(size: 32, weight: .bold, design: .rounded))
                                    .foregroundColor(.white)
                            }
                            
                            Text(viewModel.userName)
                                .font(.title3)
                                .fontWeight(.bold)
                                .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                            
                            Text(viewModel.userEmail)
                                .font(.subheadline)
                                .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textSecondaryLight, dark: Constants.Colors.textSecondaryDark, scheme: colorScheme))
                            
                            if authViewModel.isGuestMode {
                                Text("Guest Account (Offline)")
                                    .font(.caption2)
                                    .fontWeight(.bold)
                                    .foregroundColor(Constants.Colors.warning)
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 4)
                                    .background(Constants.Colors.warning.opacity(0.12))
                                    .cornerRadius(8)
                            }
                        }
                        .padding(.vertical, 20)
                        .frame(maxWidth: .infinity)
                        .premiumCard(scheme: colorScheme)
                        .padding(.horizontal)
                        
                        // Average Pronunciation Score gauge card
                        VStack(spacing: 12) {
                            Text("PRONUNCIATION FLUENCY")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(.gray)
                            
                            let avgScore = viewModel.averagePronunciationScore
                            Text("\(Int(avgScore))%")
                                .font(.system(size: 48, weight: .bold, design: .rounded))
                                .foregroundColor(avgScore >= 80 ? Constants.Colors.success : (avgScore >= 50 ? Constants.Colors.warning : Constants.Colors.danger))
                            
                            ProgressView(value: avgScore, total: 100)
                                .accentColor(avgScore >= 80 ? Constants.Colors.success : (avgScore >= 50 ? Constants.Colors.warning : Constants.Colors.danger))
                                .padding(.horizontal, 24)
                            
                            Text("Your average correctness across all speech evaluations.")
                                .font(.caption)
                                .foregroundColor(.gray)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)
                        }
                        .padding(.vertical, 20)
                        .premiumCard(scheme: colorScheme)
                        .padding(.horizontal)
                        
                        // Grid of Stats
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                            // Total Projects
                            ProfileStatCard(
                                title: "Projects",
                                value: "\(viewModel.totalProjects)",
                                icon: "folder.fill",
                                color: Constants.Colors.primaryGradientStart
                            )
                            
                            // Saved Words
                            ProfileStatCard(
                                title: "Word Basket",
                                value: "\(viewModel.totalWords)",
                                icon: "archivebox.fill",
                                color: Constants.Colors.primaryGradientEnd
                            )
                            
                            // Practice Sessions
                            ProfileStatCard(
                                title: "Speak Tests",
                                value: "\(viewModel.totalPracticeSessions)",
                                icon: "waveform.and.mic",
                                color: Constants.Colors.accentSecondary
                            )
                            
                            // XP Points
                            ProfileStatCard(
                                title: "Points (XP)",
                                value: "\(viewModel.totalPracticeSessions * 15)",
                                icon: "bolt.fill",
                                color: Color.orange
                            )
                        }
                        .padding(.horizontal)
                        
                        // Logout Action
                        Button(action: {
                            HapticManager.shared.triggerMedium()
                            Task {
                                await authViewModel.logout()
                            }
                        }) {
                            HStack {
                                Image(systemName: "arrow.right.square")
                                Text(authViewModel.isGuestMode ? "Sign In / Register" : "Sign Out")
                                    .fontWeight(.bold)
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(authViewModel.isGuestMode ? Constants.Colors.primaryGradientStart : Constants.Colors.danger)
                            .cornerRadius(12)
                            .shadow(color: (authViewModel.isGuestMode ? Constants.Colors.primaryGradientStart : Constants.Colors.danger).opacity(0.2), radius: 6, x: 0, y: 3)
                        }
                        .padding()
                        
                        Spacer().frame(height: 20)
                    }
                }
            }
            .navigationTitle("My Profile")
            .onAppear {
                viewModel.fetchProfileStats()
            }
        }
    }
}

struct ProfileStatCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(color)
                    .font(.title2)
                Spacer()
            }
            
            VStack(alignment: .leading, spacing: 2) {
                Text(value)
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textPrimaryLight, dark: Constants.Colors.textPrimaryDark, scheme: colorScheme))
                Text(title)
                    .font(.caption)
                    .foregroundColor(Color.adaptiveColor(light: Constants.Colors.textSecondaryLight, dark: Constants.Colors.textSecondaryDark, scheme: colorScheme))
                    .fontWeight(.semibold)
            }
        }
        .premiumCard(scheme: colorScheme)
    }
}
