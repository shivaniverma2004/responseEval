import Foundation

enum Config {
    /// Retrieve the Supabase API URL.
    /// You should replace this placeholder with your actual Supabase URL.
    static var supabaseURL: URL {
        if let urlString = Bundle.main.object(forInfoDictionaryKey: "SUPABASE_URL") as? String,
           let url = URL(string: urlString) {
            return url
        }
        // Fallback or placeholder
        return URL(string: "https://your-project-id.supabase.co")!
    }
    
    /// Retrieve the Supabase Anon / Client key.
    /// You should replace this placeholder with your actual Anon Key.
    static var supabaseAnonKey: String {
        if let key = Bundle.main.object(forInfoDictionaryKey: "SUPABASE_ANON_KEY") as? String {
            return key
        }
        // Fallback or placeholder
        return "your-supabase-anon-key-placeholder"
    }
    
    /// Retrieve the Gemini API Key.
    /// You should replace this placeholder with your actual Gemini API Key.
    static var geminiAPIKey: String {
        if let key = Bundle.main.object(forInfoDictionaryKey: "GEMINI_API_KEY") as? String {
            return key
        }
        // Fallback or placeholder - Replace with your own key for testing
        return "your-gemini-api-key-placeholder"
    }
}
