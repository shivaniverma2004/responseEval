import SwiftUI

// MARK: - Color Extension for Design Tokens
extension Color {
    static func adaptiveColor(light: Color, dark: Color, scheme: ColorScheme) -> Color {
        return scheme == .dark ? dark : light
    }
}

// MARK: - String Extensions for Pronunciation Matching & Cleaning
extension String {
    /// Normalizes text for comparison (removes punctuation, lowercases, trims whitespace).
    var normalizedForSpeech: String {
        self.trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { !$0.isEmpty }
            .joined(separator: " ")
    }
    
    /// Computes the similarity score (0 to 100) compared to another string using Levenshtein distance.
    func similarity(to other: String) -> Double {
        let s1 = self.normalizedForSpeech
        let s2 = other.normalizedForSpeech
        
        if s1.isEmpty && s2.isEmpty { return 100.0 }
        if s1.isEmpty || s2.isEmpty { return 0.0 }
        if s1 == s2 { return 100.0 }
        
        let distance = Levenshtein.distance(between: s1, and: s2)
        let maxLength = max(s1.count, s2.count)
        
        let percentage = (1.0 - (Double(distance) / Double(maxLength))) * 100.0
        return max(0.0, min(100.0, percentage))
    }
}

// MARK: - Levenshtein Distance Algorithm
private enum Levenshtein {
    static func distance(between s: String, and t: String) -> Int {
        let sCount = s.count
        let tCount = t.count
        
        if sCount == 0 { return tCount }
        if tCount == 0 { return sCount }
        
        let sChars = Array(s)
        let tChars = Array(t)
        
        var matrix = [[Int]](repeating: [Int](repeating: 0, count: tCount + 1), count: sCount + 1)
        
        for i in 0...sCount {
            matrix[i][0] = i
        }
        
        for j in 0...tCount {
            matrix[0][j] = j
        }
        
        for i in 1...sCount {
            for j in 1...tCount {
                if sChars[i - 1] == tChars[j - 1] {
                    matrix[i][j] = matrix[i - 1][j - 1]
                } else {
                    matrix[i][j] = min(
                        matrix[i - 1][j] + 1,      // deletion
                        matrix[i][j - 1] + 1,      // insertion
                        matrix[i - 1][j - 1] + 1   // substitution
                    )
                }
            }
        }
        
        return matrix[sCount][tCount]
    }
}

// MARK: - Safe Collection Access
extension Collection {
    subscript(safe index: Index) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}

// MARK: - View Modifiers for Styling Card Layouts
struct PremiumCardModifier: ViewModifier {
    var colorScheme: ColorScheme
    
    func body(content: Content) -> some View {
        content
            .padding(Constants.Layout.cardPadding)
            .background(Color.adaptiveColor(
                light: Constants.Colors.cardBackgroundLight,
                dark: Constants.Colors.cardBackgroundDark,
                scheme: colorScheme
            ))
            .cornerRadius(Constants.Layout.cornerRadius)
            .shadow(color: Constants.Layout.shadowColor, radius: Constants.Layout.shadowRadius, x: 0, y: 4)
    }
}

extension View {
    func premiumCard(scheme: ColorScheme) -> some View {
        self.modifier(PremiumCardModifier(colorScheme: scheme))
    }
}
