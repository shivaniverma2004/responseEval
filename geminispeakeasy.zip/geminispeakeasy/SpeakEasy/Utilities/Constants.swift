import SwiftUI

enum Constants {
    // MARK: - API Endpoints
    static let dictionaryAPIBaseURL = "https://api.dictionaryapi.dev/api/v2/entries/en/"
    static let geminiAPIBaseURL = "https://generativelanguage.googleapis.com/v1beta/models/"
    static let geminiModel = "gemini-1.5-flash"
    
    // MARK: - UserDefaults Keys
    enum UserDefaultsKeys {
        static let isUserLoggedIn = "speakeasy_is_logged_in"
        static let isGuestMode = "speakeasy_is_guest_mode"
        static let userSessionToken = "speakeasy_session_token"
        static let userEmail = "speakeasy_user_email"
        static let userName = "speakeasy_user_name"
        static let dailyReadingGoalMinutes = "speakeasy_daily_reading_goal_minutes"
        static let currentStreak = "speakeasy_current_streak"
        static let lastActiveDate = "speakeasy_last_active_date"
    }
    
    // MARK: - Design Token Colors
    enum Colors {
        static let primaryGradientStart = Color(red: 0.05, green: 0.40, blue: 0.95) // Vibrant Blue
        static let primaryGradientEnd = Color(red: 0.35, green: 0.15, blue: 0.85)   // Deep Indigo
        
        static let accentSecondary = Color(red: 0.0, green: 0.80, blue: 0.70)     // Bright Teal
        
        static let backgroundLight = Color(red: 0.96, green: 0.97, blue: 1.0)
        static let backgroundDark = Color(red: 0.05, green: 0.06, blue: 0.09)
        
        static let cardBackgroundLight = Color.white
        static let cardBackgroundDark = Color(red: 0.11, green: 0.12, blue: 0.18)
        
        static let textPrimaryLight = Color(red: 0.08, green: 0.09, blue: 0.15)
        static let textPrimaryDark = Color(red: 0.95, green: 0.96, blue: 0.98)
        
        static let textSecondaryLight = Color(red: 0.45, green: 0.48, blue: 0.55)
        static let textSecondaryDark = Color(red: 0.65, green: 0.68, blue: 0.75)
        
        static let borderLight = Color(red: 0.88, green: 0.90, blue: 0.94)
        static let borderDark = Color(red: 0.18, green: 0.20, blue: 0.28)
        
        static let success = Color(red: 0.15, green: 0.68, blue: 0.37)
        static let warning = Color(red: 0.95, green: 0.61, blue: 0.07)
        static let danger = Color(red: 0.90, green: 0.29, blue: 0.23)
        
        // Reader Themes
        static let readerSepiaBg = Color(red: 0.96, green: 0.94, blue: 0.88)
        static let readerSepiaText = Color(red: 0.20, green: 0.15, blue: 0.05)
    }
    
    // MARK: - Layout & Shadows
    enum Layout {
        static let cornerRadius: CGFloat = 16
        static let cardPadding: CGFloat = 16
        static let shadowRadius: CGFloat = 10
        static let shadowColor = Color.black.opacity(0.06)
    }
}
