import SwiftUI

enum ReaderThemePreset: String, CaseIterable, Identifiable {
    case light = "Light"
    case sepia = "Sepia"
    case dark = "Dark"
    
    var id: String { self.rawValue }
    
    var backgroundColor: Color {
        switch self {
        case .light: return Color.white
        case .sepia: return Constants.Colors.readerSepiaBg
        case .dark: return Constants.Colors.backgroundDark
        }
    }
    
    var textColor: Color {
        switch self {
        case .light: return Constants.Colors.textPrimaryLight
        case .sepia: return Constants.Colors.readerSepiaText
        case .dark: return Constants.Colors.textPrimaryDark
        }
    }
}

struct ReaderLayoutConfig {
    var fontSize: CGFloat = 18.0
    var letterSpacing: CGFloat = 0.0 // 0 to 4pt
    var lineSpacing: CGFloat = 6.0   // line spacing in points
    var theme: ReaderThemePreset = .light
}
