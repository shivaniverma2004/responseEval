# SpeakEasy iOS App - Production Readme

SpeakEasy is a premium, offline-first iOS application designed to build confidence in English learners by helping them practice pronunciation, read documents, extract text via Vision-based OCR, and leverage AI analysis (Gemini).

## Tech Stack
* **UI Framework:** SwiftUI (iOS 16+)
* **Local Persistence:** Core Data (Local-first, offline-first)
* **Auth Backend:** Supabase (REST-based Auth, secure session handling)
* **AI Pipelines:** Google Gemini Developer API (Comprehension quizzes, simplification, grammar check, summarization)
* **Dictionary:** Free Dictionary API integration
* **On-Device Frameworks:** Vision (OCR), AVFoundation (Text-to-Speech), Speech (Speech-to-Text transcription)

---

## Workspace Layout

The code files have been structured in a clean, modular MVVM pattern under the workspace:

```
SpeakEasy/
├── App/
│   └── SpeakEasyApp.swift             # App main container & route router
├── Models/
│   └── ReadingTheme.swift             # Font, Spacing, and color theme models
├── ViewModels/
│   ├── AuthViewModel.swift            # Supabase sign up, login, and guest persistence
│   ├── DashboardViewModel.swift       # Home stats and user streak analytics
│   ├── ProjectViewModel.swift         # Project CRUD and image staging files
│   ├── ReaderViewModel.swift          # E-reader text tokenizer & Gemini actions
│   ├── PracticeViewModel.swift        # Microphone recorders and string similarity tests
│   ├── WordBasketViewModel.swift      # Vocabulary list filters and difficulty categories
│   └── ProfileViewModel.swift         # Total averages of learned items and metrics
├── Views/
│   ├── Auth/
│   │   ├── LoginView.swift            # Standard fields matching HIG guides
│   │   └── SignupView.swift           # Registration cards
│   ├── Dashboard/
│   │   └── DashboardView.swift        # Main dashboard screen
│   ├── Projects/
│   │   ├── ProjectsTabView.swift      # Project collections tab
│   │   ├── ImageReviewView.swift      # Review selected photos, trigger OCR
│   │   └── ProjectDetailView.swift    # Photos display list belonging to projects
│   ├── Reader/
│   │   ├── ReaderView.swift           # Interactive word tapping and TTS speeds
│   │   ├── TextFormatSheet.swift      # Letter spacing and custom font scales
│   │   ├── AISettingsSheet.swift      # Summarize and Quiz interfaces
│   │   └── WordDetailSheet.swift      # Lexicon definitions sheet
│   ├── Practice/
│   │   └── PronunciationPracticeView.swift # Target score gauges and mic recorders
│   ├── WordBasket/
│   │   └── WordBasketView.swift       # Filterable saved word card grid
│   ├── Profile/
│   │   └── ProfileView.swift          # Statistics dashboard and sign outs
│   └── Components/
│       ├── ImagePicker.swift          # Camera and Library selection wrapper
│       └── FlowLayout.swift           # Word wrapping layout container
├── Managers/
│   ├── CoreDataManager.swift          # Local SQLite context manager and entity bindings
│   ├── SupabaseManager.swift          # Native GoTrue authentication client
│   ├── GeminiManager.swift            # Gemini 1.5 Flash assistant wrappers
│   ├── DictionaryManager.swift        # Phonetic audio dictionary parser
│   ├── SpeechManager.swift            # Unified TTS Synthesizer and STT AudioEngine
│   ├── OCRManager.swift               # Offline vision-based character identifier
│   └── HapticManager.swift            # Dynamic tactile phone vibrations
└── Utilities/
    ├── Config.swift                   # API credentials wrapper
    ├── Constants.swift                # Accent gradients and UserDefaults keys
    └── Extensions.swift               # Levenshtein string edit distances
```

---

## Setup Instructions (Running in Xcode)

Follow these steps to build and compile SpeakEasy on your macOS device running Xcode:

### 1. Create a New Project in Xcode
1. Open Xcode and select **Create a new Xcode project**.
2. Select **iOS -> App** and click Next.
3. Use the product name **SpeakEasy**, select **SwiftUI** for the interface, and **Swift** for the language.
4. Uncheck **Use Core Data** (we have built a custom, unified manager to ensure clean, crash-free setup on Windows, avoiding automatic template issues).

### 2. Copy the Files
1. Copy the `SpeakEasy` folder from this workspace directory into your new Xcode project folder.
2. Drag the folders into your Xcode Project Navigator. When prompted, check **Copy items if needed** and **Create groups**.

### 3. Add Privacy Permissions in `Info.plist`
To prevent the app from crashing when requesting device access, you must configure the following permission usage descriptions in your project's Target Info settings or your `Info.plist` file:

| Key | Description / Value |
| :--- | :--- |
| `Privacy - Camera Usage Description` | "SpeakEasy needs camera access to scan physical pages and translate English documents." |
| `Privacy - Photo Library Usage Description` | "SpeakEasy needs photo library access to import reading cards." |
| `Privacy - Microphone Usage Description` | "SpeakEasy needs microphone access to record and evaluate your pronunciation." |
| `Privacy - Speech Recognition Usage Description` | "SpeakEasy needs speech recognition access to transcribe and score your speech." |

### 4. Set Up Configuration Credentials
Open [Config.swift](file:///c:/Users/Admin/Desktop/geminispeakeasy/SpeakEasy/Utilities/Config.swift) and plug in your keys. Alternatively, you can add them to your `Info.plist` as:
* `SUPABASE_URL`: Your Supabase project URL (e.g. `https://xxxx.supabase.co`).
* `SUPABASE_ANON_KEY`: Your project's anonymous api client key.
* `GEMINI_API_KEY`: Your developer API Key for Google Gemini.
